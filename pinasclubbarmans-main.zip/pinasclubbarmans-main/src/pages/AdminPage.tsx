import React, { useState } from 'react';
import { Shield, Upload, Image, Video, MessageSquare, BarChart3, Settings, Eye, Home } from 'lucide-react';
import { Link } from 'react-router-dom';
import SupabaseStatus from '../components/admin/SupabaseStatus';
import UploadForm from '../components/admin/UploadForm';
import HeroImageForm from '../components/admin/HeroImageForm';
import VideoForm from '../components/admin/VideoForm';
import TestimonialForm from '../components/admin/TestimonialForm';
import AnalyticsPanel from '../components/admin/AnalyticsPanel';
import SetupInstructions from '../components/admin/SetupInstructions';

const AdminPage: React.FC = () => {
  const [activeTab, setActiveTab] = useState('gallery');

  const tabs = [
    { id: 'setup', label: 'Guia de Setup', icon: Settings },
    { id: 'gallery', label: 'Galeria', icon: Upload },
    { id: 'hero', label: 'Imagem Principal', icon: Image },
    { id: 'video', label: 'Vídeo Sobre', icon: Video },
    { id: 'testimonials', label: 'Depoimentos', icon: MessageSquare },
    { id: 'analytics', label: 'Analytics', icon: BarChart3 },
  ];

  const renderTabContent = () => {
    switch (activeTab) {
      case 'setup':
        return <SetupInstructions />;
      case 'gallery':
        return <UploadForm />;
      case 'hero':
        return <HeroImageForm />;
      case 'video':
        return <VideoForm />;
      case 'testimonials':
        return <TestimonialForm />;
      case 'analytics':
        return <AnalyticsPanel />;
      default:
        return <UploadForm />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-black to-gray-900">
      {/* Header */}
      <header className="bg-black/50 backdrop-blur border-b border-gray-800/50 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-4">
              <div className="flex items-center gap-3">
                <div className="w-10 h-10 bg-gradient-to-br from-gold-500 to-gold-600 rounded-xl flex items-center justify-center">
                  <Shield size={24} className="text-white" />
                </div>
                <div>
                  <h1 className="font-playfair text-2xl font-bold text-white">
                    Painel Admin
                  </h1>
                  <p className="font-inter text-gray-400 text-sm">
                    Piña Club Barmans
                  </p>
                </div>
              </div>
            </div>
            
            <div className="flex items-center gap-4">
              <Link
                to="/"
                className="flex items-center gap-2 bg-gray-800/50 hover:bg-gray-700/50 text-gray-300 hover:text-white px-4 py-2 rounded-lg transition-all duration-200 font-inter border border-gray-700/30"
              >
                <Eye size={18} />
                Ver Site
              </Link>
              
              <Link
                to="/"
                className="flex items-center gap-2 bg-gradient-to-r from-gold-500 to-gold-600 hover:from-gold-600 hover:to-gold-700 text-white px-4 py-2 rounded-lg transition-all duration-200 font-inter font-medium"
              >
                <Home size={18} />
                Voltar ao Site
              </Link>
            </div>
          </div>
        </div>
      </header>

      <div className="max-w-7xl mx-auto px-4 py-8">
        {/* Supabase Status */}
        <SupabaseStatus />

        {/* Navigation Tabs */}
        <div className="bg-gray-800/30 backdrop-blur border border-gray-700/30 rounded-2xl p-2 mb-8">
          <div className="flex flex-wrap gap-2">
            {tabs.map((tab) => {
              const IconComponent = tab.icon;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id)}
                  className={`flex items-center gap-3 px-6 py-4 rounded-xl font-inter font-medium transition-all duration-300 ${
                    activeTab === tab.id
                      ? 'bg-gradient-to-r from-gold-500 to-gold-600 text-white shadow-lg transform scale-[1.02]'
                      : 'text-gray-400 hover:text-white hover:bg-gray-700/50'
                  }`}
                >
                  <IconComponent size={20} />
                  {tab.label}
                </button>
              );
            })}
          </div>
        </div>

        {/* Tab Content */}
        <div className="animate-fade-in-up">
          {renderTabContent()}
        </div>
      </div>
    </div>
  );
};

export default AdminPage;