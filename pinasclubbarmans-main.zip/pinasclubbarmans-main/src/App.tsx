import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import HomePage from './pages/HomePage';
import AdminPage from './pages/AdminPage';
import { initializeSecurity } from './utils/security';
import { useAnalytics } from './hooks/useAnalytics';

// Initialize security measures
if (typeof window !== 'undefined') {
  initializeSecurity();
}

function App() {
  // Initialize analytics tracking
  useAnalytics();

  return (
    <div className="relative">

      <Router>
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/admin" element={<AdminPage />} />
        </Routes>
      </Router>
    </div>
  );
}

export default App;