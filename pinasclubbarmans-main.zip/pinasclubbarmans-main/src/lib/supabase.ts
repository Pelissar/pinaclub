import { createClient } from '@supabase/supabase-js';

// Get environment variables
const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
const supabaseAnonKey = import.meta.env.VITE_SUPABASE_ANON_KEY || import.meta.env.VITE_SUPABASE_KEY;

// Check if Supabase is configured
const isConfigured = !!(supabaseUrl && supabaseAnonKey);

if (!isConfigured) {
  console.warn('⚠️ Supabase não configurado. Configure as variáveis de ambiente no Netlify.');
}

// Create Supabase client with safe fallbacks
export const supabase = createClient(
  supabaseUrl || 'https://example.supabase.co',
  supabaseAnonKey || 'example-anon-key'
);

// Check connection status
export const isSupabaseConfigured = () => {
  return isConfigured && 
         supabaseUrl !== 'https://example.supabase.co' && 
         supabaseAnonKey !== 'example-anon-key';
};

// Database types
export interface Database {
  public: {
    Tables: {
      gallery_items: {
        Row: {
          id: string;
          url: string;
          caption: string;
          type: 'image' | 'video';
          created_at: string;
        };
        Insert: {
          id?: string;
          url: string;
          caption: string;
          type?: 'image' | 'video';
          created_at?: string;
        };
        Update: {
          id?: string;
          url?: string;
          caption?: string;
          type?: 'image' | 'video';
          created_at?: string;
        };
      };
      testimonials: {
        Row: {
          id: string;
          client_name: string;
          client_photo: string;
          testimonial_text: string;
          rating: number;
          event_type: string;
          created_at: string;
        };
        Insert: {
          id?: string;
          client_name: string;
          client_photo: string;
          testimonial_text?: string;
          rating?: number;
          event_type: string;
          created_at?: string;
        };
        Update: {
          id?: string;
          client_name?: string;
          client_photo?: string;
          testimonial_text?: string;
          rating?: number;
          event_type?: string;
          created_at?: string;
        };
      };
      site_settings: {
        Row: {
          id: string;
          setting_key: string;
          setting_value: string;
          setting_type: string;
          created_at: string;
          updated_at: string;
        };
        Insert: {
          id?: string;
          setting_key: string;
          setting_value: string;
          setting_type?: string;
          created_at?: string;
          updated_at?: string;
        };
        Update: {
          id?: string;
          setting_key?: string;
          setting_value?: string;
          setting_type?: string;
          created_at?: string;
          updated_at?: string;
        };
      };
    };
  };
}