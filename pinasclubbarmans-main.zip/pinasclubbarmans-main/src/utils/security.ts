// Security utilities to protect source code
export const initializeSecurity = () => {
  // Disable right-click context menu
  document.addEventListener('contextmenu', (e) => {
    e.preventDefault();
    return false;
  });

  // Disable F12, Ctrl+U, Ctrl+Shift+I/J/C
  document.addEventListener('keydown', (e) => {
    // F12
    if (e.key === 'F12') {
      e.preventDefault();
      return false;
    }
    
    // Ctrl+U (View Source)
    if (e.ctrlKey && e.key === 'u') {
      e.preventDefault();
      return false;
    }
    
    // Ctrl+Shift+I (Developer Tools)
    if (e.ctrlKey && e.shiftKey && e.key === 'I') {
      e.preventDefault();
      return false;
    }
    
    // Ctrl+Shift+J (Console)
    if (e.ctrlKey && e.shiftKey && e.key === 'J') {
      e.preventDefault();
      return false;
    }
    
    // Ctrl+Shift+C (Element Inspector)
    if (e.ctrlKey && e.shiftKey && e.key === 'C') {
      e.preventDefault();
      return false;
    }
  });

  // Disable text selection on sensitive elements
  document.body.style.userSelect = 'none';
  document.body.style.webkitUserSelect = 'none';
  
  // Clear console periodically
  setInterval(() => {
    if (typeof console !== 'undefined') {
      console.clear();
    }
  }, 2000);
  
  // Additional protection against common inspection methods
  Object.defineProperty(window, 'console', {
    value: window.console,
    writable: false,
    configurable: false
  });
};

// Obfuscate admin route
export const getAdminRoute = () => {
  const routes = ['admin', 'painel', 'dashboard', 'gerenciar', 'manage'];
  return `/${routes[0]}`;
};