import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { X, ChevronLeft, ChevronRight, Martini } from 'lucide-react';
import { useGallery } from '../hooks/useGallery';

const Gallery: React.FC = () => {
  const { items, isLoading, error } = useGallery();
  const [selectedImage, setSelectedImage] = useState<number | null>(null);

  // Debug: Log para verificar se os itens estão sendo carregados
  useEffect(() => {
    console.log('🖼️ Gallery component - items updated:', items.length);
    if (items.length > 0) {
      console.log('Latest item:', items[0]);
    }
  }, [items]);

  const openModal = useCallback((index: number) => {
    setSelectedImage(index);
  }, []);

  const closeModal = useCallback(() => {
    setSelectedImage(null);
  }, []);

  const goToPrevious = useCallback(() => {
    setSelectedImage(prev => prev === null ? null : prev > 0 ? prev - 1 : items.length - 1);
  }, [items.length]);

  const goToNext = useCallback(() => {
    setSelectedImage(prev => prev === null ? null : prev < items.length - 1 ? prev + 1 : 0);
  }, [items.length]);

  // Handle keyboard events for modal
  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (selectedImage !== null) {
        if (e.key === 'Escape') {
          closeModal();
        } else if (e.key === 'ArrowLeft') {
          goToPrevious();
        } else if (e.key === 'ArrowRight') {
          goToNext();
        }
      }
    };

    document.addEventListener('keydown', handleKeyDown);
    return () => document.removeEventListener('keydown', handleKeyDown);
  }, [selectedImage, closeModal, goToPrevious, goToNext]);

  // Prevent body scroll when modal is open
  useEffect(() => {
    if (selectedImage !== null) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [selectedImage]);

  const galleryItems = useMemo(() => items, [items]);

  if (isLoading) {
    return (
      <section className="py-20 bg-gray-900">
        <div className="max-w-6xl mx-auto px-4 text-center">
          <div className="animate-pulse">
            <div className="h-8 bg-gray-700 rounded w-64 mx-auto mb-4"></div>
            <div className="h-4 bg-gray-700 rounded w-48 mx-auto mb-8"></div>
            <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
              {Array.from({ length: 6 }).map((_, i) => (
                <div key={i} className="bg-gray-700 rounded-2xl h-64"></div>
              ))}
            </div>
          </div>
        </div>
      </section>
    );
  }

  if (error) {
    return (
      <section className="py-20 bg-gray-900">
        <div className="max-w-6xl mx-auto px-4 text-center">
          <div className="bg-red-900/20 border border-red-500/30 rounded-2xl p-8">
            <h2 className="font-playfair text-2xl font-bold text-red-400 mb-4">
              Erro ao Carregar Galeria
            </h2>
            <p className="text-red-300 mb-4">{error}</p>
            <button
              onClick={() => window.location.reload()}
              className="bg-red-600 hover:bg-red-700 text-white px-6 py-3 rounded-lg transition-colors duration-200"
            >
              Tentar Novamente
            </button>
          </div>
        </div>
      </section>
    );
  }
  return (
    <section id="gallery" className="py-20 bg-gray-900 relative overflow-hidden">
      {/* Background Effects */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute top-10 right-20 w-40 h-40 bg-gold-500 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-20 left-20 w-32 h-32 bg-gold-600 rounded-full blur-3xl animate-pulse animation-delay-500"></div>
      </div>
      
      <div className="max-w-6xl mx-auto px-4">
        <div className="text-center mb-16 animate-fade-in-up">
          <h2 className="font-playfair text-4xl md:text-5xl font-bold text-white mb-6">
            Galeria de Eventos
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-gold-500 to-gold-600 mx-auto rounded-full mb-6"></div>
          <p className="font-inter text-xl text-gray-400 max-w-2xl mx-auto">
            Confira alguns momentos especiais dos nossos eventos e a qualidade do nosso trabalho
          </p>
        </div>

        {galleryItems.length === 0 ? (
          <div className="text-center py-12">
            <div className="w-24 h-24 bg-gray-800 rounded-full flex items-center justify-center mx-auto mb-4">
              <Martini size={32} className="text-gray-600" />
            </div>
            <p className="font-inter text-gray-400 text-lg">
              Em breve, novos momentos especiais dos nossos eventos.
            </p>
          </div>
        ) : (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-8 animate-fade-in-up animation-delay-300">
            {galleryItems.map((item, index) => (
              <div 
                key={item.id}
                className="group bg-black/50 backdrop-blur border border-gray-800 rounded-2xl p-6 hover:border-gold-500/50 transition-all duration-300 hover:transform hover:scale-[1.02] hover:shadow-2xl hover:shadow-gold-500/20 relative will-change-transform animate-fade-in-up cursor-pointer"
                style={{ animationDelay: `${index * 150}ms` }}
                onClick={() => openModal(index)}
              >
                {/* Media */}
                <div className="mb-4 cursor-pointer">
                  {item.type === 'video' ? (
                    <video
                      src={item.url}
                      className="w-full rounded-lg object-cover border-2 border-gold-500/30 select-none pointer-events-none no-select no-drag max-h-64 transition-transform duration-300 group-hover:scale-105"
                      muted
                      loop
                      playsInline
                      preload="metadata"
                      loading="lazy"
                      draggable="false"
                      onContextMenu={(e) => e.preventDefault()}
                      onDragStart={(e) => e.preventDefault()}
                    />
                  ) : (
                    <img
                      src={item.url}
                      alt={item.caption}
                      className="w-full rounded-lg object-cover border-2 border-gold-500/30 select-none pointer-events-none no-select no-drag max-h-64 transition-transform duration-300 group-hover:scale-105"
                      loading="lazy"
                      decoding="async"
                      draggable="false"
                      onContextMenu={(e) => e.preventDefault()}
                      onDragStart={(e) => e.preventDefault()}
                    />
                  )}
                </div>

                {/* Caption */}
                <div className="mb-3">
                  <h3 className="font-inter font-semibold text-white text-lg group-hover:text-gold-400 transition-colors duration-300">
                    {item.caption}
                  </h3>
                  <p className="font-inter text-gold-400 text-sm">
                    {item.type === 'video' ? 'Vídeo do Evento' : 'Foto do Evento'}
                  </p>
                </div>

                {/* Date */}
                <p className="font-inter text-gray-500 text-xs">
                  {new Date(item.createdAt).toLocaleDateString('pt-BR')}
                </p>

                {/* Marca d'água */}
                <div className="absolute bottom-2 right-2 flex items-center gap-1 bg-black/60 backdrop-blur-sm px-2 py-1 rounded-full opacity-70">
                  <img 
                    src="/Imagem do WhatsApp de 2025-07-21 à(s) 22.13.53_a3cebc65.jpg"
                    alt="Piña Club Logo"
                    className="w-4 h-4 rounded-full object-cover select-none pointer-events-none no-select no-drag"
                    loading="lazy"
                    decoding="async"
                    draggable="false"
                    onContextMenu={(e) => e.preventDefault()}
                    onDragStart={(e) => e.preventDefault()}
                  />
                  <span className="font-playfair text-white font-bold text-xs">Piña Club</span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Modal - Igual ao dos Feedbacks */}
      {selectedImage !== null && (
        <div 
          className="fixed inset-0 bg-black/90 z-50 flex items-center justify-center p-4 no-select cursor-pointer"
          onContextMenu={(e) => e.preventDefault()}
          onClick={closeModal}
        >
          <div 
            className="relative max-w-4xl w-full cursor-default"
            onClick={(e) => e.stopPropagation()}
          >
            {/* Close button */}
            <button
              onClick={closeModal}
              className="absolute -top-16 right-0 z-10 w-12 h-12 bg-black/70 hover:bg-black/90 rounded-full flex items-center justify-center text-white hover:text-gold-500 transition-all duration-200 backdrop-blur-sm border border-white/20"
              title="Fechar (ESC)"
            >
              <X size={24} />
            </button>
            
            {/* Navigation buttons */}
            {galleryItems.length > 1 && (
              <>
                <button
                  onClick={goToPrevious}
                  className="absolute left-4 top-1/2 transform -translate-y-1/2 z-10 w-12 h-12 bg-black/70 hover:bg-black/90 rounded-full flex items-center justify-center text-white hover:text-gold-500 transition-all duration-200 backdrop-blur-sm border border-white/20"
                  title="Anterior (←)"
                >
                  <ChevronLeft size={24} />
                </button>
                
                <button
                  onClick={goToNext}
                  className="absolute right-4 top-1/2 transform -translate-y-1/2 z-10 w-12 h-12 bg-black/70 hover:bg-black/90 rounded-full flex items-center justify-center text-white hover:text-gold-500 transition-all duration-200 backdrop-blur-sm border border-white/20"
                  title="Próximo (→)"
                >
                  <ChevronRight size={24} />
                </button>
              </>
            )}

            {/* Media container */}
            <div className="relative">
              {galleryItems[selectedImage].type === 'video' ? (
                <video 
                  src={galleryItems[selectedImage].url}
                  className="w-full h-auto rounded-2xl select-none no-select no-drag max-h-[80vh] object-contain"
                  controls
                  autoPlay
                  loop
                  muted
                  playsInline
                  draggable="false"
                  onContextMenu={(e) => e.preventDefault()}
                  onDragStart={(e) => e.preventDefault()}
                />
              ) : (
                <img 
                  src={galleryItems[selectedImage].url}
                  alt={galleryItems[selectedImage].caption}
                  className="w-full h-auto rounded-2xl select-none pointer-events-none no-select no-drag max-h-[80vh] object-contain"
                  loading="eager"
                  decoding="async"
                  draggable="false"
                  onContextMenu={(e) => e.preventDefault()}
                  onDragStart={(e) => e.preventDefault()}
                />
              )}
              
              {/* Marca d'água grande no modal */}
              <div className="absolute bottom-4 right-4 flex items-center gap-2 bg-black/60 backdrop-blur-sm px-4 py-2 rounded-full">
                <img 
                  src="/Imagem do WhatsApp de 2025-07-21 à(s) 22.13.53_a3cebc65.jpg"
                  alt="Piña Club Logo"
                  className="w-8 h-8 rounded-full object-cover select-none pointer-events-none no-select no-drag"
                  loading="lazy"
                  decoding="async"
                  draggable="false"
                  onContextMenu={(e) => e.preventDefault()}
                  onDragStart={(e) => e.preventDefault()}
                />
                <span className="font-playfair text-white font-bold text-lg">Piña Club Barmans</span>
              </div>
            </div>
            
            {/* Caption and info */}
            <div className="mt-6 text-center">
              <div className="bg-black/50 backdrop-blur-sm rounded-2xl p-6 border border-gold-500/20">
                <h3 className="font-playfair text-2xl font-bold text-white mb-2">
                  {galleryItems[selectedImage].caption}
                </h3>
                <p className="font-inter text-gold-400 text-lg mb-3">
                  {galleryItems[selectedImage].type === 'video' ? 'Vídeo do Evento' : 'Foto do Evento'}
                </p>
                
                {/* Date and counter */}
                <div className="flex justify-between items-center text-sm">
                  <p className="font-inter text-gray-400">
                    {new Date(galleryItems[selectedImage].createdAt).toLocaleDateString('pt-BR')}
                  </p>
                  <p className="font-inter text-gray-400">
                    {selectedImage + 1} de {galleryItems.length}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </section>
  );
};

export default Gallery;