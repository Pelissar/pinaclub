import React from 'react';
import { useAboutVideo } from '../hooks/useAboutVideo';

const About: React.FC = () => {
  const { videoUrl } = useAboutVideo();
  
  console.log('🎬 About component - current video URL:', videoUrl ? videoUrl.substring(0, 50) + '...' : 'empty');

  return (
    <section id="about" className="py-20 bg-gray-900 relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute top-20 left-10 w-32 h-32 bg-gold-500 rounded-full blur-3xl"></div>
        <div className="absolute bottom-20 right-10 w-40 h-40 bg-gold-600 rounded-full blur-3xl"></div>
      </div>
      
      <div className="max-w-6xl mx-auto px-4">
        <div className="text-center mb-16 animate-fade-in-up">
          <h2 className="font-playfair text-4xl md:text-5xl font-bold text-white mb-6">
            Sobre Nós
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-gold-500 to-gold-600 mx-auto rounded-full"></div>
        </div>

        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div className="space-y-6 animate-fade-in-left">
            <p className="font-inter text-lg text-gray-300 leading-relaxed">
              A <strong className="text-gold-400">Piña Club Barmans</strong> é especializada em serviços premium de bartending para casamentos, festas privadas, eventos corporativos e celebrações especiais em Andradina-SP e região.
            </p>
            
            <p className="font-inter text-lg text-gray-300 leading-relaxed">
              Com mais de <strong className="text-gold-400">5 anos de experiência</strong> no mercado, nossa equipe de bartenders profissionais oferece estrutura completa, drinks autorais exclusivos e um atendimento personalizado que transforma qualquer evento em uma experiência única e memorável.
            </p>

            <div className="bg-black/30 backdrop-blur p-6 rounded-xl border border-gold-500/20">
              <h3 className="font-playfair text-xl font-bold text-gold-400 mb-3">
                Por que escolher a Piña Club?
              </h3>
              <ul className="space-y-3 text-gray-300">
                <li className="flex items-center gap-3">
                  <span className="w-3 h-3 bg-gradient-to-r from-gold-500 to-gold-600 rounded-full animate-pulse"></span>
                  Bartenders certificados e experientes
                </li>
                <li className="flex items-center gap-3">
                  <span className="w-3 h-3 bg-gradient-to-r from-gold-500 to-gold-600 rounded-full animate-pulse animation-delay-200"></span>
                  Drinks autorais e receitas exclusivas
                </li>
                <li className="flex items-center gap-3">
                  <span className="w-3 h-3 bg-gradient-to-r from-gold-500 to-gold-600 rounded-full animate-pulse animation-delay-400"></span>
                  Equipamentos profissionais e setup completo
                </li>
                <li className="flex items-center gap-3">
                  <span className="w-3 h-3 bg-gradient-to-r from-gold-500 to-gold-600 rounded-full animate-pulse animation-delay-600"></span>
                  Atendimento personalizado para cada evento
                </li>
              </ul>
            </div>

            <div className="flex flex-wrap gap-4 pt-6">
              <div className="bg-black/50 backdrop-blur px-6 py-3 rounded-full border border-gold-500/30 hover:border-gold-500/60 hover:bg-black/70 transition-all duration-300 cursor-pointer transform hover:scale-105">
                <span className="text-gold-500 font-inter font-medium">Eventos Corporativos</span>
              </div>
              <div className="bg-black/50 backdrop-blur px-6 py-3 rounded-full border border-gold-500/30 hover:border-gold-500/60 hover:bg-black/70 transition-all duration-300 cursor-pointer transform hover:scale-105">
                <span className="text-gold-500 font-inter font-medium">Casamentos</span>
              </div>
              <div className="bg-black/50 backdrop-blur px-6 py-3 rounded-full border border-gold-500/30 hover:border-gold-500/60 hover:bg-black/70 transition-all duration-300 cursor-pointer transform hover:scale-105">
                <span className="text-gold-500 font-inter font-medium">Festas Privadas</span>
              </div>
            </div>
          </div>

          <div className="relative animate-fade-in-right">
            <div className="relative overflow-hidden rounded-2xl shadow-2xl">
              {videoUrl ? (
                <video 
                  key={videoUrl} // Force re-render when URL changes
                  src={videoUrl}
                  controls
                  loop
                  muted
                  playsInline
                  preload="metadata"
                  className="w-full h-96 object-cover select-none no-select no-drag"
                  onContextMenu={(e) => e.preventDefault()}
                  onDragStart={(e) => e.preventDefault()}
                  onLoadStart={() => console.log('🎬 Video load started')}
                  onLoadedData={() => console.log('✅ Video loaded successfully')}
                  onError={(e) => {
                    console.error('❌ Video load error:', videoUrl);
                    console.error('Error details:', e);
                  }}
                />
              ) : (
                <div className="w-full h-96 bg-gray-800 flex items-center justify-center rounded-2xl">
                  <div className="text-center">
                    <div className="w-16 h-16 bg-gray-700 rounded-full flex items-center justify-center mx-auto mb-4">
                      <svg className="w-8 h-8 text-gray-500" fill="currentColor" viewBox="0 0 20 20">
                        <path d="M8 5v10l7-5-7-5z"/>
                      </svg>
                    </div>
                    <p className="text-gray-400 font-inter">
                      Nenhum vídeo configurado
                    </p>
                    <p className="text-gray-500 text-sm font-inter mt-2">
                      Configure um vídeo no painel admin
                    </p>
                  </div>
                </div>
              )}
              <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent"></div>
              
              {/* Marca d'água no vídeo */}
              {videoUrl && (
                <div className="absolute bottom-4 right-4 flex items-center gap-2 bg-black/50 backdrop-blur-sm px-3 py-1 rounded-full">
                  <img 
                    src="/Imagem do WhatsApp de 2025-07-21 à(s) 22.13.53_a3cebc65.jpg"
                    alt="Piña Club Logo"
                    className="w-6 h-6 rounded-full object-cover select-none pointer-events-none no-select no-drag"
                    loading="lazy"
                    decoding="async"
                    draggable="false"
                    onContextMenu={(e) => e.preventDefault()}
                    onDragStart={(e) => e.preventDefault()}
                  />
                  <span className="font-playfair text-white font-bold text-sm">Piña Club</span>
                </div>
              )}
            </div>
            
            {/* Floating elements */}
            <div className="absolute -top-4 -right-4 w-20 h-20 bg-gradient-to-br from-pink-500 to-pink-600 rounded-full opacity-80 blur-sm will-change-transform animate-float"></div>
            <div className="absolute -bottom-4 -left-4 w-16 h-16 bg-gradient-to-br from-gold-500 to-gold-600 rounded-full opacity-60 blur-sm will-change-transform animate-float-reverse"></div>
          </div>
        </div>
      </div>
    </section>
  )
}

export default About