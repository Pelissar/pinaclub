import React from 'react';
import { AlertTriangle, CheckCircle, ExternalLink } from 'lucide-react';
import { isSupabaseConfigured } from '../../lib/supabase';

const SupabaseStatus: React.FC = () => {
  const isConfigured = isSupabaseConfigured();
  
  // Debug info for development
  const supabaseUrl = import.meta.env.VITE_SUPABASE_URL;
  const hasKey = !!(import.meta.env.VITE_SUPABASE_ANON_KEY || import.meta.env.VITE_SUPABASE_KEY);

  if (isConfigured) {
    return (
      <div className="bg-green-900/20 border border-green-500/30 rounded-xl p-4 mb-6">
        <div className="flex items-center gap-3">
          <CheckCircle size={20} className="text-green-400" />
          <div>
            <h4 className="font-inter font-semibold text-green-400">Supabase Conectado</h4>
            <p className="text-green-300 text-sm">
              Banco de dados funcionando normalmente
              {import.meta.env.DEV && (
                <span className="block text-xs text-green-400 mt-1">
                  URL: {supabaseUrl?.substring(0, 30)}...
                </span>
              )}
            </p>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="bg-red-900/20 border border-red-500/30 rounded-xl p-6 mb-6">
      <div className="flex items-start gap-4">
        <AlertTriangle size={24} className="text-red-400 flex-shrink-0 mt-1" />
        <div className="flex-1">
          <h4 className="font-inter font-bold text-red-400 text-lg mb-2">
            ⚠️ Supabase Não Configurado
          </h4>
          <p className="text-red-300 mb-4">
            O painel admin não consegue salvar dados porque as variáveis de ambiente do Supabase não estão configuradas.
          </p>
          
          <div className="bg-red-800/30 rounded-lg p-4 mb-4">
            <h5 className="font-inter font-semibold text-red-200 mb-2">
              🔧 Como Corrigir:
            </h5>
            
            {import.meta.env.DEV && (
              <div className="bg-red-800/20 rounded-lg p-3 mb-3 text-xs">
                <p className="text-red-300 mb-1">🔍 Debug Info:</p>
                <p className="text-red-400">URL: {supabaseUrl || 'não configurada'}</p>
                <p className="text-red-400">Key: {hasKey ? 'configurada' : 'não configurada'}</p>
              </div>
            )}
            
            <ol className="text-red-200 text-sm space-y-2 list-decimal list-inside">
              <li>Acesse <strong>Site Settings → Environment Variables</strong> no Netlify</li>
              <li>Adicione <code className="bg-red-800/30 px-1 rounded">VITE_SUPABASE_URL</code></li>
              <li>Adicione <code className="bg-red-800/30 px-1 rounded">VITE_SUPABASE_ANON_KEY</code></li>
              <li>Faça um novo deploy</li>
            </ol>
          </div>

          <div className="flex gap-3">
            <a
              href="https://supabase.com"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg transition-colors duration-200 text-sm font-medium"
            >
              <ExternalLink size={16} />
              Criar Conta Supabase
            </a>
            
            <a
              href="https://docs.netlify.com/environment-variables/overview/"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition-colors duration-200 text-sm font-medium"
            >
              <ExternalLink size={16} />
              Config Netlify
            </a>
          </div>
        </div>
      </div>
    </div>
  );
};

export default SupabaseStatus;