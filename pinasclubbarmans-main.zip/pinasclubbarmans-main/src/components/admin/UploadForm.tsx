import React, { useState, useRef } from 'react';
import { Upload, Image, Video, X, Check, FileImage, FileVideo } from 'lucide-react';
import { useGallery } from '../../hooks/useGallery';

const UploadForm: React.FC = () => {
  const { addItem } = useGallery();
  const [caption, setCaption] = useState('');
  const [dragActive, setDragActive] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [preview, setPreview] = useState<string | null>(null);
  const [fileType, setFileType] = useState<'image' | 'video' | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [fileName, setFileName] = useState<string>('');
  const [fileSize, setFileSize] = useState<string>('');

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFile(e.dataTransfer.files[0]);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    e.preventDefault();
    if (e.target.files && e.target.files[0]) {
      handleFile(e.target.files[0]);
    }
  };

  const handleFile = (file: File) => {
    if (!file.type.startsWith('image/') && !file.type.startsWith('video/')) {
      alert('Por favor, selecione apenas arquivos de imagem ou vídeo.');
      return;
    }

    const type = file.type.startsWith('image/') ? 'image' : 'video';
    setFileType(type);
    setFileName(file.name);
    setFileSize((file.size / (1024 * 1024)).toFixed(2) + ' MB');

    // Create Data URL for persistent storage
    const reader = new FileReader();
    reader.onload = (e) => {
      const dataUrl = e.target?.result as string;
      setPreview(dataUrl);
    };
    reader.readAsDataURL(file);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!preview || !caption.trim()) {
      alert('Por favor, selecione um arquivo e adicione uma legenda.');
      return;
    }

    setUploading(true);

    try {
      // Add item to Supabase database
      const newItem = await addItem(preview, caption.trim(), fileType || 'image');
      console.log('✅ New item added to gallery:', newItem);
      
      setSuccess(true);
      setTimeout(() => {
        setSuccess(false);
        resetForm();
      }, 2000);
    } catch (error) {
      console.error('Erro no upload:', error);
      const errorMessage = error instanceof Error ? error.message : 'Erro desconhecido';
      alert(`Erro ao fazer upload: ${errorMessage}`);
    } finally {
      setUploading(false);
    }
  };

  const resetForm = () => {
    setCaption('');
    setPreview(null);
    setFileType(null);
    setFileName('');
    setFileSize('');
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  return (
    <div className="bg-gray-800/40 backdrop-blur border border-gray-700/30 rounded-2xl p-6">
      <div className="flex items-center gap-3 mb-6">
        <Upload size={24} className="text-green-400" />
        <h3 className="font-playfair text-xl font-bold text-white">Upload de Mídia</h3>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* File Upload Area */}
        <div
          className={`relative border-2 border-dashed rounded-2xl p-8 text-center transition-all duration-300 ${
            dragActive
              ? 'border-blue-500 bg-blue-500/10 scale-[1.02]'
              : preview
              ? 'border-green-500 bg-green-500/10'
              : 'border-gray-600/50 hover:border-gray-500/70 hover:bg-gray-800/30'
          }`}
          onDragEnter={handleDrag}
          onDragLeave={handleDrag}
          onDragOver={handleDrag}
          onDrop={handleDrop}
        >
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*,video/*"
            onChange={handleChange}
            className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
          />

          {preview ? (
            <div className="space-y-4">
              <div className="flex items-center justify-center gap-2 text-green-400 mb-4">
                {fileType === 'image' ? <FileImage size={24} /> : <FileVideo size={24} />}
                <span className="font-inter font-medium">Arquivo selecionado</span>
              </div>
              
              {fileType === 'image' ? (
                <img
                  src={preview}
                  alt="Preview"
                  className="max-w-full max-h-48 mx-auto rounded-xl shadow-lg border border-gray-600/30"
                />
              ) : (
                <video
                  src={preview}
                  className="max-w-full max-h-48 mx-auto rounded-xl shadow-lg border border-gray-600/30"
                  controls
                />
              )}
              
              <div className="bg-gray-800/50 rounded-lg p-3 text-left">
                <p className="text-white text-sm font-medium mb-1">{fileName}</p>
                <p className="text-gray-400 text-xs">Tamanho: {fileSize}</p>
              </div>
              
              <button
                type="button"
                onClick={resetForm}
                className="text-gray-400 hover:text-red-400 transition-colors duration-200 p-2 hover:bg-gray-800/50 rounded-lg"
              >
                <X size={18} />
              </button>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="flex justify-center">
                <div className="w-16 h-16 bg-gray-700/50 rounded-2xl flex items-center justify-center">
                  <Upload size={32} className="text-gray-400" />
                </div>
              </div>
              <div>
                <p className="font-inter text-white font-medium mb-2">
                  Arraste arquivos aqui ou clique para selecionar
                </p>
                <p className="font-inter text-gray-400 text-sm">
                  Imagens e vídeos de eventos são aceitos
                </p>
              </div>
            </div>
          )}
        </div>

        {/* Caption Input */}
        <div>
          <label htmlFor="caption" className="block font-inter font-medium text-white mb-3">
            Legenda
          </label>
          <textarea
            id="caption"
            value={caption}
            onChange={(e) => setCaption(e.target.value)}
            placeholder="Descreva este momento do evento..."
            className="w-full px-4 py-4 bg-gray-800/50 border border-gray-600/50 rounded-xl text-white placeholder-gray-400 focus:border-blue-500 focus:ring-2 focus:ring-blue-500/20 transition-all duration-200 resize-none font-inter"
            rows={3}
            required
          />
        </div>

        {/* Submit Button */}
        <button
          type="submit"
          disabled={uploading || !preview || !caption.trim()}
          className={`w-full py-4 px-6 rounded-xl font-inter font-semibold transition-all duration-300 flex items-center justify-center gap-3 ${
            success
              ? 'bg-green-600 text-white shadow-lg'
              : uploading || !preview || !caption.trim()
              ? 'bg-gray-700/50 text-gray-400 cursor-not-allowed'
              : 'bg-gradient-to-r from-blue-500 to-blue-600 hover:from-blue-600 hover:to-blue-700 text-white transform hover:scale-[1.02] shadow-lg'
          }`}
        >
          {success ? (
            <>
              <Check size={20} />
              Upload realizado com sucesso!
            </>
          ) : uploading ? (
            <>
              <div className="animate-spin rounded-full h-6 w-6 border-2 border-white border-t-transparent"></div>
              Fazendo upload...
            </>
          ) : (
            <>
              <Upload size={22} />
              Adicionar à Galeria
            </>
          )}
        </button>
      </form>
    </div>
  );
};

export default UploadForm;