import React, { useState, useRef } from 'react';
import { Upload, User, Star, Check, X, MessageSquare, FileImage, FileVideo } from 'lucide-react';
import { useTestimonials } from '../../hooks/useTestimonials';

const TestimonialForm: React.FC = () => {
  const { addTestimonial } = useTestimonials();
  const [clientName, setClientName] = useState('');
  const [rating, setRating] = useState(5);
  const [eventType, setEventType] = useState('');
  const [dragActive, setDragActive] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [preview, setPreview] = useState<string | null>(null);
  const [fileType, setFileType] = useState<'image' | 'video' | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [fileName, setFileName] = useState<string>('');
  const [fileSize, setFileSize] = useState<string>('');

  const eventTypes = [
    'Casamento',
    'Aniversário',
    'Evento Corporativo',
    'Festa Privada',
    'Formatura',
    'Outro'
  ];

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFile(e.dataTransfer.files[0]);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    e.preventDefault();
    if (e.target.files && e.target.files[0]) {
      handleFile(e.target.files[0]);
    }
  };

  const handleFile = (file: File) => {
    if (!file.type.startsWith('image/') && !file.type.startsWith('video/')) {
      alert('Por favor, selecione apenas arquivos de imagem ou vídeo.');
      return;
    }

    const type = file.type.startsWith('image/') ? 'image' : 'video';
    setFileType(type);
    setFileName(file.name);
    setFileSize((file.size / (1024 * 1024)).toFixed(2) + ' MB');

    // Create Data URL for persistent storage
    const reader = new FileReader();
    reader.onload = (e) => {
      const dataUrl = e.target?.result as string;
      setPreview(dataUrl);
    };
    reader.readAsDataURL(file);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!preview || !clientName.trim() || !eventType) {
      alert('Por favor, preencha todos os campos e adicione uma imagem ou vídeo.');
      return;
    }

    setUploading(true);

    try {
      // Add testimonial to Supabase database
      const newTestimonial = await addTestimonial(
        clientName.trim(),
        preview,
        '', // Empty testimonial text since we're only using media
        rating,
        eventType
      );
      console.log('✅ New testimonial added:', newTestimonial);
      
      setSuccess(true);
      setTimeout(() => {
        setSuccess(false);
        resetForm();
      }, 2000);
    } catch (error) {
      console.error('Erro no upload:', error);
      const errorMessage = error instanceof Error ? error.message : 'Erro desconhecido';
      alert(`Erro ao adicionar depoimento: ${errorMessage}`);
    } finally {
      setUploading(false);
    }
  };

  const resetForm = () => {
    setClientName('');
    setRating(5);
    setEventType('');
    setPreview(null);
    setFileType(null);
    setFileName('');
    setFileSize('');
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const renderStars = () => {
    return Array.from({ length: 5 }, (_, i) => (
      <button
        key={i}
        type="button"
        onClick={() => setRating(i + 1)}
        className={`transition-colors duration-200 ${
          i < rating ? 'text-yellow-400' : 'text-gray-600 hover:text-yellow-300'
        }`}
      >
        <Star size={24} className={i < rating ? 'fill-current' : ''} />
      </button>
    ));
  };

  return (
    <div className="bg-gray-800/40 backdrop-blur border border-gray-700/30 rounded-2xl p-6">
      <div className="flex items-center gap-3 mb-6">
        <MessageSquare size={24} className="text-orange-400" />
        <h3 className="font-playfair text-xl font-bold text-white">Adicionar Feedback</h3>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Media Upload */}
        <div>
          <label className="block font-inter font-medium text-white mb-3">
            Imagem ou Vídeo do Feedback
          </label>
          <div
            className={`relative border-2 border-dashed rounded-2xl p-8 text-center transition-all duration-300 ${
              dragActive
                ? 'border-green-500 bg-green-500/10 scale-[1.02]'
                : preview
                ? 'border-green-500 bg-green-500/10'
                : 'border-gray-600/50 hover:border-gray-500/70 hover:bg-gray-800/30'
            }`}
            onDragEnter={handleDrag}
            onDragLeave={handleDrag}
            onDragOver={handleDrag}
            onDrop={handleDrop}
          >
            <input
              ref={fileInputRef}
              type="file"
              accept="image/*,video/*"
              onChange={handleChange}
              className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
            />

            {preview ? (
              <div className="space-y-4">
                <div className="flex items-center justify-center gap-2 text-green-400 mb-4">
                  {fileType === 'image' ? <FileImage size={24} /> : <FileVideo size={24} />}
                  <span className="font-inter font-medium">Feedback selecionado</span>
                </div>
                
                {fileType === 'image' ? (
                  <img
                    src={preview}
                    alt="Preview"
                    className="max-w-full max-h-48 mx-auto rounded-xl object-cover shadow-lg border border-gray-600/30"
                  />
                ) : (
                  <video
                    src={preview}
                    className="max-w-full max-h-48 mx-auto rounded-xl shadow-lg border border-gray-600/30"
                    controls
                  />
                )}
                
                <div className="bg-gray-800/50 rounded-lg p-3 text-left">
                  <p className="text-white text-sm font-medium mb-1">{fileName}</p>
                  <p className="text-gray-400 text-xs">Tamanho: {fileSize}</p>
                </div>
                
                <button
                  type="button"
                  onClick={resetForm}
                  className="text-gray-400 hover:text-red-400 transition-colors duration-200 p-2 hover:bg-gray-800/50 rounded-lg"
                >
                  <X size={18} />
                </button>
              </div>
            ) : (
              <div className="space-y-4">
                <div className="flex justify-center">
                  <div className="w-16 h-16 bg-gray-700/50 rounded-2xl flex items-center justify-center">
                    <Upload size={32} className="text-gray-400" />
                  </div>
                </div>
                <div>
                  <p className="font-inter text-white font-medium mb-2">
                    Adicionar feedback do cliente
                  </p>
                  <p className="font-inter text-gray-400 text-sm">
                    Screenshots de conversas, vídeos de depoimentos, fotos do evento, etc.
                  </p>
                </div>
              </div>
            )}
          </div>
        </div>

        {/* Client Name */}
        <div>
          <label htmlFor="clientName" className="block font-inter font-medium text-white mb-3">
            Nome do Cliente
          </label>
          <input
            type="text"
            id="clientName"
            value={clientName}
            onChange={(e) => setClientName(e.target.value)}
            placeholder="Ex: Maria Silva"
            className="w-full px-4 py-4 bg-gray-800/50 border border-gray-600/50 rounded-xl text-white placeholder-gray-400 focus:border-green-500 focus:ring-2 focus:ring-green-500/20 transition-all duration-200 font-inter"
            required
          />
        </div>

        {/* Event Type */}
        <div>
          <label htmlFor="eventType" className="block font-inter font-medium text-white mb-3">
            Tipo de Evento
          </label>
          <select
            id="eventType"
            value={eventType}
            onChange={(e) => setEventType(e.target.value)}
            className="w-full px-4 py-4 bg-gray-800/50 border border-gray-600/50 rounded-xl text-white focus:border-green-500 focus:ring-2 focus:ring-green-500/20 transition-all duration-200 font-inter"
            required
          >
            <option value="">Selecione o tipo de evento</option>
            {eventTypes.map((type) => (
              <option key={type} value={type}>
                {type}
              </option>
            ))}
          </select>
        </div>

        {/* Rating */}
        <div>
          <label className="block font-inter font-medium text-white mb-3">
            Avaliação
          </label>
          <div className="flex gap-2 p-2">
            {renderStars()}
          </div>
        </div>

        {/* Testimonial Text */}
        {/* Submit Button */}
        <button
          type="submit"
          disabled={uploading || !preview || !clientName.trim() || !eventType}
          className={`w-full py-4 px-6 rounded-xl font-inter font-semibold transition-all duration-300 flex items-center justify-center gap-3 ${
            success
              ? 'bg-green-600 text-white shadow-lg'
              : uploading || !preview || !clientName.trim() || !eventType
              ? 'bg-gray-700/50 text-gray-400 cursor-not-allowed'
              : 'bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white transform hover:scale-[1.02] shadow-lg'
          }`}
        >
          {success ? (
            <>
              <Check size={20} />
              Feedback adicionado!
            </>
          ) : uploading ? (
            <>
              <div className="animate-spin rounded-full h-6 w-6 border-2 border-white border-t-transparent"></div>
              Adicionando feedback...
            </>
          ) : (
            <>
              <Upload size={22} />
              Adicionar Feedback
            </>
          )}
        </button>
      </form>
    </div>
  );
};

export default TestimonialForm;