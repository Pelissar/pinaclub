import React, { useState } from 'react';
import { Book, ExternalLink, Copy, Check, ChevronDown, ChevronRight } from 'lucide-react';

const SetupInstructions: React.FC = () => {
  const [copiedStep, setCopiedStep] = useState<string | null>(null);
  const [expandedSection, setExpandedSection] = useState<string>('supabase');

  const copyToClipboard = (text: string, stepId: string) => {
    navigator.clipboard.writeText(text);
    setCopiedStep(stepId);
    setTimeout(() => setCopiedStep(null), 2000);
  };

  const sqlScript = `-- Criar tabela de itens da galeria
CREATE TABLE IF NOT EXISTS gallery_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  url text NOT NULL,
  caption text NOT NULL,
  type text DEFAULT 'image' CHECK (type IN ('image', 'video')),
  created_at timestamptz DEFAULT now()
);

-- Criar tabela de depoimentos
CREATE TABLE IF NOT EXISTS testimonials (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  client_name text NOT NULL,
  client_photo text NOT NULL,
  testimonial_text text DEFAULT '',
  rating integer DEFAULT 5 CHECK (rating >= 1 AND rating <= 5),
  event_type text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Criar tabela de configurações do site
CREATE TABLE IF NOT EXISTS site_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  setting_key text UNIQUE NOT NULL,
  setting_value text NOT NULL,
  setting_type text DEFAULT 'text',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Habilitar RLS (Row Level Security)
ALTER TABLE gallery_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE testimonials ENABLE ROW LEVEL SECURITY;
ALTER TABLE site_settings ENABLE ROW LEVEL SECURITY;

-- Políticas para galeria
CREATE POLICY "Permitir leitura pública da galeria" ON gallery_items
  FOR SELECT TO anon, authenticated USING (true);

CREATE POLICY "Permitir inserção para usuários autenticados" ON gallery_items
  FOR INSERT TO authenticated WITH CHECK (true);

CREATE POLICY "Permitir atualização para usuários autenticados" ON gallery_items
  FOR UPDATE TO authenticated USING (true);

CREATE POLICY "Permitir exclusão para usuários autenticados" ON gallery_items
  FOR DELETE TO authenticated USING (true);

-- Políticas para depoimentos
CREATE POLICY "Permitir leitura pública dos depoimentos" ON testimonials
  FOR SELECT TO anon, authenticated USING (true);

CREATE POLICY "Permitir inserção para usuários autenticados" ON testimonials
  FOR INSERT TO authenticated WITH CHECK (true);

CREATE POLICY "Permitir atualização para usuários autenticados" ON testimonials
  FOR UPDATE TO authenticated USING (true);

CREATE POLICY "Permitir exclusão para usuários autenticados" ON testimonials
  FOR DELETE TO authenticated USING (true);

-- Políticas para configurações do site
CREATE POLICY "Permitir leitura pública das configurações" ON site_settings
  FOR SELECT TO anon, authenticated USING (true);

CREATE POLICY "Permitir atualização para usuários autenticados" ON site_settings
  FOR ALL TO authenticated USING (true) WITH CHECK (true);`;

  const Section = ({ id, title, children, icon }: { id: string; title: string; children: React.ReactNode; icon: React.ReactNode }) => {
    const isExpanded = expandedSection === id;
    
    return (
      <div className="bg-gray-800/30 rounded-xl border border-gray-700/30 mb-4">
        <button
          onClick={() => setExpandedSection(isExpanded ? '' : id)}
          className="w-full flex items-center justify-between p-4 text-left hover:bg-gray-700/20 transition-colors duration-200 rounded-xl"
        >
          <div className="flex items-center gap-3">
            {icon}
            <h3 className="font-playfair text-lg font-bold text-white">{title}</h3>
          </div>
          {isExpanded ? <ChevronDown size={20} className="text-gray-400" /> : <ChevronRight size={20} className="text-gray-400" />}
        </button>
        
        {isExpanded && (
          <div className="px-4 pb-4 space-y-4">
            {children}
          </div>
        )}
      </div>
    );
  };

  return (
    <div className="bg-gray-800/40 backdrop-blur border border-gray-700/30 rounded-2xl p-6">
      <div className="flex items-center gap-3 mb-6">
        <Book size={24} className="text-blue-400" />
        <h2 className="font-playfair text-xl font-bold text-white">Guia de Configuração</h2>
      </div>

      <div className="mb-6 p-4 bg-blue-900/20 border border-blue-500/30 rounded-xl">
        <p className="text-blue-300 text-sm">
          📋 <strong>Siga este guia passo-a-passo</strong> para configurar o Supabase e fazer o painel admin funcionar perfeitamente.
        </p>
      </div>

      <Section
        id="supabase"
        title="1. 🗄️ Configurar Supabase"
        icon={<div className="w-8 h-8 bg-green-500/20 rounded-lg flex items-center justify-center"><span className="text-green-400 font-bold">1</span></div>}
      >
        <div className="space-y-4">
          <div className="bg-gray-700/30 rounded-lg p-4">
            <h4 className="font-inter font-semibold text-white mb-2">Passo 1.1: Criar Conta</h4>
            <ol className="text-gray-300 text-sm space-y-1 list-decimal list-inside">
              <li>Acesse <a href="https://supabase.com" target="_blank" rel="noopener noreferrer" className="text-blue-400 hover:text-blue-300">supabase.com</a></li>
              <li>Clique em <strong>"Start your project"</strong></li>
              <li>Faça login com GitHub, Google ou email</li>
            </ol>
          </div>

          <div className="bg-gray-700/30 rounded-lg p-4">
            <h4 className="font-inter font-semibold text-white mb-2">Passo 1.2: Criar Projeto</h4>
            <ol className="text-gray-300 text-sm space-y-1 list-decimal list-inside">
              <li>Clique em <strong>"New Project"</strong></li>
              <li>Escolha uma Organization (ou crie uma)</li>
              <li>Preencha:
                <ul className="ml-4 mt-1 space-y-1 list-disc list-inside">
                  <li><strong>Name:</strong> pina-club-barmans</li>
                  <li><strong>Database Password:</strong> (crie uma senha forte)</li>
                  <li><strong>Region:</strong> South America (São Paulo)</li>
                </ul>
              </li>
              <li>Clique em <strong>"Create new project"</strong></li>
              <li>⏳ Aguarde 2-3 minutos para o projeto ser criado</li>
            </ol>
          </div>

          <div className="bg-gray-700/30 rounded-lg p-4">
            <h4 className="font-inter font-semibold text-white mb-2">Passo 1.3: Obter Credenciais</h4>
            <ol className="text-gray-300 text-sm space-y-1 list-decimal list-inside mb-3">
              <li>No painel do Supabase, vá em <strong>Settings → API</strong></li>
              <li>Copie e salve estas informações:</li>
            </ol>
            <div className="bg-gray-800/50 rounded-lg p-3 font-mono text-xs">
              <div className="text-gray-400 mb-1">Project URL:</div>
              <div className="text-green-400 mb-3">https://xxxxxxxxx.supabase.co</div>
              <div className="text-gray-400 mb-1">anon public:</div>
              <div className="text-green-400">eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...</div>
            </div>
          </div>

          <div className="bg-gray-700/30 rounded-lg p-4">
            <h4 className="font-inter font-semibold text-white mb-2">Passo 1.4: Configurar Banco de Dados</h4>
            <ol className="text-gray-300 text-sm space-y-1 list-decimal list-inside mb-3">
              <li>Vá em <strong>SQL Editor</strong></li>
              <li>Clique em <strong>"New query"</strong></li>
              <li>Cole e execute este código:</li>
            </ol>
            
            <div className="relative">
              <button
                onClick={() => copyToClipboard(sqlScript, 'sql')}
                className="absolute top-2 right-2 z-10 flex items-center gap-1 bg-gray-700/80 hover:bg-gray-600/80 text-white px-3 py-1 rounded-lg text-xs transition-colors duration-200"
              >
                {copiedStep === 'sql' ? <Check size={14} /> : <Copy size={14} />}
                {copiedStep === 'sql' ? 'Copiado!' : 'Copiar'}
              </button>
              
              <pre className="bg-gray-800/50 rounded-lg p-4 text-xs text-gray-300 overflow-x-auto max-h-64 overflow-y-auto">
                <code>{sqlScript}</code>
              </pre>
            </div>
            
            <p className="text-gray-300 text-sm mt-2">
              4. Clique em <strong>"Run"</strong> para executar<br/>
              5. ✅ <strong>Sucesso!</strong> Tabelas criadas
            </p>
          </div>
        </div>
      </Section>

      <Section
        id="netlify"
        title="2. 🌐 Configurar Netlify"
        icon={<div className="w-8 h-8 bg-blue-500/20 rounded-lg flex items-center justify-center"><span className="text-blue-400 font-bold">2</span></div>}
      >
        <div className="space-y-4">
          <div className="bg-gray-700/30 rounded-lg p-4">
            <h4 className="font-inter font-semibold text-white mb-2">Passo 2.1: Acessar Dashboard</h4>
            <ol className="text-gray-300 text-sm space-y-1 list-decimal list-inside">
              <li>Acesse <a href="https://app.netlify.com" target="_blank" rel="noopener noreferrer" className="text-blue-400 hover:text-blue-300">app.netlify.com</a></li>
              <li>Encontre seu site na lista</li>
              <li>Clique no nome do site</li>
            </ol>
          </div>

          <div className="bg-gray-700/30 rounded-lg p-4">
            <h4 className="font-inter font-semibold text-white mb-2">Passo 2.2: Configurar Variáveis</h4>
            <ol className="text-gray-300 text-sm space-y-1 list-decimal list-inside">
              <li>Vá em <strong>Site settings</strong></li>
              <li>No menu lateral, clique em <strong>Environment variables</strong></li>
              <li>Clique em <strong>"Add a variable"</strong></li>
            </ol>
          </div>

          <div className="bg-gray-700/30 rounded-lg p-4">
            <h4 className="font-inter font-semibold text-white mb-2">Passo 2.3: Adicionar Variáveis</h4>
            <p className="text-gray-300 text-sm mb-3">Adicione estas <strong>2 variáveis</strong> (uma por vez):</p>
            
            <div className="space-y-3">
              <div className="bg-gray-800/50 rounded-lg p-3">
                <div className="text-green-400 font-semibold text-sm mb-2">Variável 1:</div>
                <div className="font-mono text-xs space-y-1">
                  <div><span className="text-gray-400">Key:</span> <span className="text-white">VITE_SUPABASE_URL</span></div>
                  <div><span className="text-gray-400">Value:</span> <span className="text-green-400">https://xxxxxxxxx.supabase.co</span> (sua URL)</div>
                  <div><span className="text-gray-400">Scopes:</span> <span className="text-white">All deploy contexts</span></div>
                </div>
              </div>
              
              <div className="bg-gray-800/50 rounded-lg p-3">
                <div className="text-green-400 font-semibold text-sm mb-2">Variável 2:</div>
                <div className="font-mono text-xs space-y-1">
                  <div><span className="text-gray-400">Key:</span> <span className="text-white">VITE_SUPABASE_ANON_KEY</span> <span className="text-gray-500">(ou VITE_SUPABASE_KEY)</span></div>
                  <div><span className="text-gray-400">Value:</span> <span className="text-green-400">eyJhbGciOiJIUzI1NiIs...</span> (sua chave)</div>
                  <div><span className="text-gray-400">Scopes:</span> <span className="text-white">All deploy contexts</span></div>
                </div>
              </div>
            </div>
          </div>

          <div className="bg-gray-700/30 rounded-lg p-4">
            <h4 className="font-inter font-semibold text-white mb-2">Passo 2.4: Fazer Novo Deploy</h4>
            <ol className="text-gray-300 text-sm space-y-1 list-decimal list-inside">
              <li>Vá em <strong>Deploys</strong></li>
              <li>Clique em <strong>"Trigger deploy"</strong> → <strong>"Deploy site"</strong></li>
              <li>⏳ Aguarde o deploy terminar (1-2 minutos)</li>
            </ol>
          </div>
        </div>
      </Section>

      <Section
        id="test"
        title="3. ✅ Testar Funcionamento"
        icon={<div className="w-8 h-8 bg-green-500/20 rounded-lg flex items-center justify-center"><span className="text-green-400 font-bold">3</span></div>}
      >
        <div className="space-y-4">
          <div className="bg-gray-700/30 rounded-lg p-4">
            <h4 className="font-inter font-semibold text-white mb-2">Teste 1: Verificar Conexão</h4>
            <ol className="text-gray-300 text-sm space-y-1 list-decimal list-inside">
              <li>Acesse seu site no Netlify</li>
              <li>Vá para <code className="bg-gray-800/50 px-2 py-1 rounded text-green-400">/admin</code> (adicione /admin na URL)</li>
              <li>Verifique se aparece:
                <ul className="ml-4 mt-1 space-y-1 list-disc list-inside">
                  <li>✅ <span className="text-green-400">"Supabase Conectado"</span> (verde)</li>
                  <li>❌ <span className="text-red-400">"Supabase Não Configurado"</span> (vermelho)</li>
                </ul>
              </li>
            </ol>
          </div>

          <div className="bg-gray-700/30 rounded-lg p-4">
            <h4 className="font-inter font-semibold text-white mb-2">Teste 2: Upload de Imagem</h4>
            <ol className="text-gray-300 text-sm space-y-1 list-decimal list-inside">
              <li>Na aba <strong>"Galeria"</strong></li>
              <li>Faça upload de uma imagem</li>
              <li>Adicione uma legenda</li>
              <li>Clique em <strong>"Adicionar à Galeria"</strong></li>
              <li>✅ Deve aparecer <span className="text-green-400">"Upload realizado com sucesso!"</span></li>
            </ol>
          </div>

          <div className="bg-gray-700/30 rounded-lg p-4">
            <h4 className="font-inter font-semibold text-white mb-2">Teste 3: Verificar no Site</h4>
            <ol className="text-gray-300 text-sm space-y-1 list-decimal list-inside">
              <li>Volte para a página inicial</li>
              <li>Role até a seção <strong>"Galeria de Eventos"</strong></li>
              <li>✅ Deve aparecer sua imagem</li>
            </ol>
          </div>
        </div>
      </Section>

      <div className="mt-6 p-4 bg-green-900/20 border border-green-500/30 rounded-xl">
        <h3 className="font-inter font-semibold text-green-400 mb-2">🎉 Parabéns!</h3>
        <p className="text-green-300 text-sm">
          Se chegou até aqui, seu site está <strong>100% funcional</strong> com banco de dados, painel admin e deploy automático!
        </p>
      </div>

      <div className="mt-4 flex gap-3">
        <a
          href="https://supabase.com"
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center gap-2 bg-green-600 hover:bg-green-700 text-white px-4 py-2 rounded-lg transition-colors duration-200 text-sm font-medium"
        >
          <ExternalLink size={16} />
          Acessar Supabase
        </a>
        
        <a
          href="https://app.netlify.com"
          target="_blank"
          rel="noopener noreferrer"
          className="flex items-center gap-2 bg-blue-600 hover:bg-blue-700 text-white px-4 py-2 rounded-lg transition-colors duration-200 text-sm font-medium"
        >
          <ExternalLink size={16} />
          Acessar Netlify
        </a>
      </div>
    </div>
  );
};

export default SetupInstructions;