import React from 'react';
import { BarChart3, Users, Eye, Calendar, TrendingUp, Globe, Clock, Trash2 } from 'lucide-react';
import { useAnalytics } from '../../hooks/useAnalytics';

const AnalyticsPanel: React.FC = () => {
  const { 
    analytics, 
    isLoading, 
    getVisitsByPeriod, 
    getUniqueVisitorsByPeriod,
    clearAnalytics 
  } = useAnalytics();

  if (isLoading) {
    return (
      <div className="bg-gray-800/40 backdrop-blur border border-gray-700/30 rounded-2xl p-6">
        <div className="animate-pulse space-y-4">
          <div className="h-6 bg-gray-700 rounded w-48"></div>
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            {Array.from({ length: 4 }).map((_, i) => (
              <div key={i} className="h-24 bg-gray-700 rounded-xl"></div>
            ))}
          </div>
        </div>
      </div>
    );
  }

  const today = getVisitsByPeriod(1);
  const thisWeek = getVisitsByPeriod(7);
  const thisMonth = getVisitsByPeriod(30);

  const uniqueToday = getUniqueVisitorsByPeriod(1);
  const uniqueThisWeek = getUniqueVisitorsByPeriod(7);
  const uniqueThisMonth = getUniqueVisitorsByPeriod(30);

  const handleClearAnalytics = () => {
    if (window.confirm('⚠️ ATENÇÃO: Isso irá apagar TODOS os dados de analytics. Esta ação não pode ser desfeita. Tem certeza?')) {
      clearAnalytics();
    }
  };

  return (
    <div className="bg-gray-800/40 backdrop-blur border border-gray-700/30 rounded-2xl p-6">
      <div className="flex items-center justify-between mb-6">
        <div className="flex items-center gap-3">
          <BarChart3 size={24} className="text-blue-400" />
          <h3 className="font-playfair text-xl font-bold text-white">Analytics do Site</h3>
        </div>
        <div className="text-xs text-gray-500">
          Última atualização: {new Date(analytics.lastUpdated).toLocaleString('pt-BR')}
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 mb-8">
        {/* Total Visits */}
        <div className="bg-gradient-to-br from-blue-500/10 to-blue-600/10 border border-blue-500/20 rounded-xl p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-blue-500/20 rounded-lg flex items-center justify-center">
              <Eye size={20} className="text-blue-400" />
            </div>
            <div>
              <p className="text-gray-400 text-xs font-inter">Total de Visitas</p>
              <p className="text-white text-2xl font-bold">{analytics.totalVisits}</p>
            </div>
          </div>
        </div>

        {/* Unique Visitors */}
        <div className="bg-gradient-to-br from-green-500/10 to-green-600/10 border border-green-500/20 rounded-xl p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-green-500/20 rounded-lg flex items-center justify-center">
              <Users size={20} className="text-green-400" />
            </div>
            <div>
              <p className="text-gray-400 text-xs font-inter">Visitantes Únicos</p>
              <p className="text-white text-2xl font-bold">{analytics.uniqueVisitors}</p>
            </div>
          </div>
        </div>

        {/* Today's Visits */}
        <div className="bg-gradient-to-br from-purple-500/10 to-purple-600/10 border border-purple-500/20 rounded-xl p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-purple-500/20 rounded-lg flex items-center justify-center">
              <Calendar size={20} className="text-purple-400" />
            </div>
            <div>
              <p className="text-gray-400 text-xs font-inter">Hoje</p>
              <p className="text-white text-2xl font-bold">{today.length}</p>
            </div>
          </div>
        </div>

        {/* This Week */}
        <div className="bg-gradient-to-br from-orange-500/10 to-orange-600/10 border border-orange-500/20 rounded-xl p-4">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 bg-orange-500/20 rounded-lg flex items-center justify-center">
              <TrendingUp size={20} className="text-orange-400" />
            </div>
            <div>
              <p className="text-gray-400 text-xs font-inter">Esta Semana</p>
              <p className="text-white text-2xl font-bold">{thisWeek.length}</p>
            </div>
          </div>
        </div>
      </div>

      {/* Detailed Stats */}
      <div className="grid md:grid-cols-2 gap-6 mb-6">
        {/* Period Stats */}
        <div className="bg-gray-700/30 rounded-xl p-4">
          <h4 className="font-inter font-semibold text-white mb-4 flex items-center gap-2">
            <Clock size={16} className="text-blue-400" />
            Estatísticas por Período
          </h4>
          <div className="space-y-3">
            <div className="flex justify-between items-center">
              <span className="text-gray-400 text-sm">Hoje</span>
              <div className="text-right">
                <span className="text-white font-medium">{today.length}</span>
                <span className="text-gray-500 text-xs ml-2">({uniqueToday} únicos)</span>
              </div>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-400 text-sm">Esta Semana</span>
              <div className="text-right">
                <span className="text-white font-medium">{thisWeek.length}</span>
                <span className="text-gray-500 text-xs ml-2">({uniqueThisWeek} únicos)</span>
              </div>
            </div>
            <div className="flex justify-between items-center">
              <span className="text-gray-400 text-sm">Este Mês</span>
              <div className="text-right">
                <span className="text-white font-medium">{thisMonth.length}</span>
                <span className="text-gray-500 text-xs ml-2">({uniqueThisMonth} únicos)</span>
              </div>
            </div>
          </div>
        </div>

        {/* Recent Visits */}
        <div className="bg-gray-700/30 rounded-xl p-4">
          <h4 className="font-inter font-semibold text-white mb-4 flex items-center gap-2">
            <Globe size={16} className="text-green-400" />
            Visitas Recentes
          </h4>
          <div className="space-y-2 max-h-32 overflow-y-auto">
            {analytics.visitHistory.slice(0, 5).map((visit, index) => (
              <div key={index} className="flex justify-between items-center text-sm">
                <div>
                  <span className="text-gray-400">
                    {visit.ip.substring(0, 8)}...
                  </span>
                  <span className="text-gray-500 ml-2">{visit.page}</span>
                  <span className="text-gray-600 ml-2 text-xs">
                    {visit.sessionId?.substring(0, 8)}...
                  </span>
                </div>
                <span className="text-gray-500 text-xs">
                  {new Date(visit.timestamp).toLocaleTimeString('pt-BR', {
                    hour: '2-digit',
                    minute: '2-digit'
                  })}
                </span>
              </div>
            ))}
            {analytics.visitHistory.length === 0 && (
              <p className="text-gray-500 text-sm text-center py-4">
                Nenhuma visita registrada ainda
              </p>
            )}
          </div>
        </div>
      </div>

      {/* Clear Analytics Button */}
      <div className="bg-red-900/20 border border-red-500/30 rounded-xl p-4">
        <div className="flex items-center justify-between">
          <div>
            <h4 className="font-inter font-semibold text-red-400 mb-1">Limpar Analytics</h4>
            <p className="text-gray-400 text-sm">Remove todos os dados de visitação</p>
          </div>
          <button
            onClick={handleClearAnalytics}
            className="flex items-center gap-2 bg-red-600/20 hover:bg-red-600/30 text-red-400 px-4 py-2 rounded-lg transition-all duration-200 font-inter border border-red-500/20 hover:border-red-500/40"
          >
            <Trash2 size={16} />
            Limpar
          </button>
        </div>
      </div>
    </div>
  );
};

export default AnalyticsPanel;