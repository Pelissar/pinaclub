import React, { useState, useRef } from 'react';
import { Upload, Video, Check, X, RotateCcw, FileVideo, Trash2 } from 'lucide-react';
import { useAboutVideo } from '../../hooks/useAboutVideo';

const VideoForm: React.FC = () => {
  const { videoUrl, updateVideo, resetToDefault, removeVideo, error } = useAboutVideo();
  const [dragActive, setDragActive] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [preview, setPreview] = useState<string | null>(null);
  const [selectedFile, setSelectedFile] = useState<File | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [fileName, setFileName] = useState<string>('');
  const [fileSize, setFileSize] = useState<string>('');

  const handleRemove = async () => {
    if (window.confirm('⚠️ ATENÇÃO: Isso irá REMOVER completamente o vídeo da seção "Sobre" do banco de dados. Esta ação não pode ser desfeita. Tem certeza?')) {
      try {
        await removeVideo();
        resetForm();
      } catch (error) {
        console.error('Erro ao remover vídeo:', error);
        alert('Erro ao remover vídeo. Tente novamente.');
      }
    }
  };

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFile(e.dataTransfer.files[0]);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    e.preventDefault();
    if (e.target.files && e.target.files[0]) {
      handleFile(e.target.files[0]);
    }
  };

  const handleFile = (file: File) => {
    if (!file.type.startsWith('video/')) {
      alert('Por favor, selecione apenas arquivos de vídeo.');
      return;
    }

    // Check file size (2MB limit for localStorage due to base64 encoding overhead)
    const maxSizeInMB = 3;
    const fileSizeInMB = file.size / (1024 * 1024);
    
    if (fileSizeInMB > maxSizeInMB) {
      alert(`❌ Arquivo muito grande (${fileSizeInMB.toFixed(2)}MB).\n\n📏 Limite: ${maxSizeInMB}MB para armazenamento local.\n\n💡 Dica: Use um vídeo menor ou comprima o arquivo antes do upload.`);
      return;
    }
    
    setFileName(file.name);
    setFileSize((file.size / (1024 * 1024)).toFixed(2) + ' MB');

    // Create preview URL (temporary for preview)
    const previewUrl = URL.createObjectURL(file);
    setPreview(previewUrl);
    
    // Store the file for later processing
    setSelectedFile(file);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!preview || !selectedFile) {
      alert('Por favor, selecione um vídeo.');
      return;
    }

    setUploading(true);

    try {
      // Simulate upload delay
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // Convert file to base64 with compression check
      const dataUrl = await new Promise<string>((resolve, reject) => {
        const reader = new FileReader();
        reader.onload = (e) => {
          const result = e.target?.result as string;
          
          // Check if the base64 string is too large for localStorage
          const sizeInMB = (result.length * 0.75) / (1024 * 1024);
          console.log(`📊 Video base64 size: ${sizeInMB.toFixed(2)}MB`);
          
          if (sizeInMB > 4.5) {
            reject(new Error(`Arquivo muito grande após conversão (${sizeInMB.toFixed(2)}MB). Use um vídeo menor.`));
            return;
          }
          
          resolve(result);
        };
        reader.onerror = () => reject(new Error('Erro ao processar o arquivo'));
        reader.readAsDataURL(selectedFile);
      });
      
      console.log('🎬 Updating video with base64 data...');
      updateVideo(dataUrl);
      
      // Wait a bit to ensure the update is processed
      await new Promise(resolve => setTimeout(resolve, 500));
      
      setSuccess(true);
      setTimeout(() => {
        setSuccess(false);
        resetForm();
      }, 2000);
    } catch (error) {
      console.error('Erro no upload:', error);
      const errorMessage = error instanceof Error ? error.message : 'Erro desconhecido';
      alert(`❌ Erro ao fazer upload:\n\n${errorMessage}\n\n💡 Tente usar um vídeo menor (máximo 2MB).`);
    } finally {
      setUploading(false);
    }
  };

  const resetForm = () => {
    setPreview(null);
    setFileName('');
    setFileSize('');
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleReset = () => {
    if (window.confirm('Tem certeza que deseja restaurar o vídeo padrão?')) {
      resetToDefault();
      resetForm();
    }
  };

  return (
    <div className="bg-gray-800/40 backdrop-blur border border-gray-700/30 rounded-2xl p-6">
      {error && (
        <div className="mb-4 p-4 bg-red-900/20 border border-red-500/30 rounded-xl">
          <p className="text-red-400 text-sm">❌ {error}</p>
        </div>
      )}
      
      <div className="flex items-center gap-3 mb-6">
        <Video size={24} className="text-indigo-400" />
        <h3 className="font-playfair text-xl font-bold text-white">Configurar Vídeo</h3>
      </div>

      {/* Current Video Preview */}
      <div className="mb-6">
        <h3 className="font-inter font-medium text-white mb-3">Vídeo Atual</h3>
        <div className="relative w-full h-48 rounded-xl overflow-hidden border border-gray-600/30">
          {videoUrl.includes('data:video') || videoUrl.includes('.mp4') ? (
            <video
              src={videoUrl}
              className="w-full h-full object-cover"
              controls
              muted
              preload="metadata"
              draggable="false"
              onContextMenu={(e) => e.preventDefault()}
              onDragStart={(e) => e.preventDefault()}
              onError={(e) => {
                console.error('Admin video preview error:', videoUrl);
              }}
            />
          ) : (
            <div className="w-full h-full bg-gray-800 flex items-center justify-center">
              <div className="text-center">
                <Video size={48} className="text-gray-600 mx-auto mb-2" />
                <p className="text-gray-400 text-sm">Nenhum vídeo configurado</p>
                <p className="text-gray-500 text-xs">Faça upload de um vídeo abaixo</p>
              </div>
            </div>
          )}
          <div className="absolute bottom-2 right-2 flex items-center gap-1 bg-black/60 backdrop-blur-sm px-2 py-1 rounded-full opacity-70">
            <img 
              src="/Imagem do WhatsApp de 2025-07-21 à(s) 22.13.53_a3cebc65.jpg"
              alt="Piña Club Logo"
              className="w-4 h-4 rounded-full object-cover select-none pointer-events-none no-select no-drag"
              loading="lazy"
              decoding="async"
              draggable="false"
              onContextMenu={(e) => e.preventDefault()}
              onDragStart={(e) => e.preventDefault()}
            />
            <span className="font-playfair text-white font-bold text-xs">Piña Club</span>
          </div>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* File Upload Area */}
        <div
          className={`relative border-2 border-dashed rounded-2xl p-8 text-center transition-all duration-300 ${
            dragActive
              ? 'border-indigo-500 bg-indigo-500/10 scale-[1.02]'
              : preview
              ? 'border-green-500 bg-green-500/10'
              : 'border-gray-600/50 hover:border-gray-500/70 hover:bg-gray-800/30'
          }`}
          onDragEnter={handleDrag}
          onDragLeave={handleDrag}
          onDragOver={handleDrag}
          onDrop={handleDrop}
        >
          <input
            ref={fileInputRef}
            type="file"
            accept="video/*"
            onChange={handleChange}
            className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
          />

          {preview ? (
            <div className="space-y-4">
              <div className="flex items-center justify-center gap-2 text-green-400 mb-4">
                <FileVideo size={24} />
                <span className="font-inter font-medium">Novo vídeo selecionado</span>
              </div>
              
              <video
                src={preview}
                className="max-w-full max-h-48 mx-auto rounded-xl object-cover shadow-lg border border-gray-600/30"
                controls
                muted
                preload="metadata"
              />
              
              <div className="bg-gray-800/50 rounded-lg p-3 text-left">
                <p className="text-white text-sm font-medium mb-1">{fileName}</p>
                <p className="text-gray-400 text-xs">Tamanho: {fileSize}</p>
              </div>
              
              <button
                type="button"
                onClick={resetForm}
                className="text-gray-400 hover:text-red-400 transition-colors duration-200 p-2 hover:bg-gray-800/50 rounded-lg"
              >
                <X size={18} />
              </button>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="flex justify-center">
                <div className="w-16 h-16 bg-gray-700/50 rounded-2xl flex items-center justify-center">
                  <Video size={32} className="text-gray-400" />
                </div>
              </div>
              <div>
                <p className="font-inter text-white font-medium mb-2">
                  Arraste um novo vídeo aqui ou clique para selecionar
                </p>
                <p className="font-inter text-gray-400 text-sm">
                  Formatos aceitos: MP4, WebM, MOV (máximo 3MB)
                </p>
                <p className="font-inter text-yellow-400 text-xs mt-2">
                  ⚠️ Vídeos maiores que 3MB podem não ser salvos devido ao limite do navegador
                </p>
              </div>
            </div>
          )}
        </div>

        {/* Action Buttons */}
        <div className="flex gap-3">
          <button
            type="submit"
            disabled={uploading || !preview}
            className={`flex-1 py-4 px-6 rounded-xl font-inter font-semibold transition-all duration-300 flex items-center justify-center gap-3 ${
              success
                ? 'bg-green-600 text-white shadow-lg'
                : uploading || !preview
                ? 'bg-gray-700/50 text-gray-400 cursor-not-allowed'
                : 'bg-gradient-to-r from-indigo-500 to-indigo-600 hover:from-indigo-600 hover:to-indigo-700 text-white transform hover:scale-[1.02] shadow-lg'
            }`}
          >
            {success ? (
              <>
                <Check size={20} />
                Vídeo atualizado!
              </>
            ) : uploading ? (
              <>
                <div className="animate-spin rounded-full h-6 w-6 border-2 border-white border-t-transparent"></div>
                Atualizando...
              </>
            ) : (
              <>
                <Upload size={22} />
                Atualizar Vídeo
              </>
            )}
          </button>

          <div className="flex gap-2">
            <button
              type="button"
              onClick={handleReset}
              className="px-4 py-4 border-2 border-gray-600/50 text-gray-400 hover:border-gray-500/70 hover:text-white rounded-xl font-inter font-medium transition-all duration-300 flex items-center gap-2"
            >
              <RotateCcw size={18} />
              Padrão
            </button>
            
            <button
              type="button"
              onClick={handleRemove}
              className="px-4 py-4 border-2 border-red-600/50 text-red-400 hover:border-red-500/70 hover:text-red-300 hover:bg-red-900/20 rounded-xl font-inter font-medium transition-all duration-300 flex items-center gap-2"
            >
              <Trash2 size={18} />
              Remover
            </button>
          </div>
        </div>
      </form>
    </div>
  );
};

export default VideoForm;