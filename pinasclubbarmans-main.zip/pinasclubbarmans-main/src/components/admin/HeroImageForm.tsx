import React, { useState, useRef } from 'react';
import { Upload, Image, Check, X, RotateCcw, FileImage, Trash2 } from 'lucide-react';
import { useHeroImage } from '../../hooks/useHeroImage';

const HeroImageForm: React.FC = () => {
  const { heroImageUrl, updateHeroImage, resetToDefault, removeHeroImage, error } = useHeroImage();
  const [dragActive, setDragActive] = useState(false);
  const [uploading, setUploading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [preview, setPreview] = useState<string | null>(null);
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [fileName, setFileName] = useState<string>('');
  const [fileSize, setFileSize] = useState<string>('');

  const handleRemove = async () => {
    if (window.confirm('⚠️ ATENÇÃO: Isso irá REMOVER completamente a imagem principal do banco de dados. Esta ação não pode ser desfeita. Tem certeza?')) {
      try {
        await removeHeroImage();
        resetForm();
      } catch (error) {
        console.error('Erro ao remover imagem:', error);
        alert('Erro ao remover imagem. Tente novamente.');
      }
    }
  };

  const handleDrag = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (e.type === "dragenter" || e.type === "dragover") {
      setDragActive(true);
    } else if (e.type === "dragleave") {
      setDragActive(false);
    }
  };

  const handleDrop = (e: React.DragEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setDragActive(false);
    
    if (e.dataTransfer.files && e.dataTransfer.files[0]) {
      handleFile(e.dataTransfer.files[0]);
    }
  };

  const handleChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    e.preventDefault();
    if (e.target.files && e.target.files[0]) {
      handleFile(e.target.files[0]);
    }
  };

  const handleFile = (file: File) => {
    if (!file.type.startsWith('image/')) {
      alert('Por favor, selecione apenas arquivos de imagem.');
      return;
    }

    setFileName(file.name);
    setFileSize((file.size / (1024 * 1024)).toFixed(2) + ' MB');

    // Create preview URL
    const url = URL.createObjectURL(file);
    setPreview(url);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!preview) {
      alert('Por favor, selecione uma imagem.');
      return;
    }

    setUploading(true);

    try {
      // Simulate upload delay
      await new Promise(resolve => setTimeout(resolve, 1500));
      
      // In a real app, you would upload to a server/cloud storage
      // For this demo, we'll use the preview URL
      updateHeroImage(preview);
      
      setSuccess(true);
      setTimeout(() => {
        setSuccess(false);
        resetForm();
      }, 2000);
    } catch (error) {
      console.error('Erro no upload:', error);
      const errorMessage = error instanceof Error ? error.message : 'Erro desconhecido';
      alert(`Erro ao fazer upload: ${errorMessage}`);
    } finally {
      setUploading(false);
    }
  };

  const resetForm = () => {
    setPreview(null);
    setFileName('');
    setFileSize('');
    if (fileInputRef.current) {
      fileInputRef.current.value = '';
    }
  };

  const handleReset = () => {
    if (window.confirm('Tem certeza que deseja restaurar a imagem padrão?')) {
      resetToDefault();
      resetForm();
    }
  };

  return (
    <div className="bg-gray-800/40 backdrop-blur border border-gray-700/30 rounded-2xl p-6">
      {error && (
        <div className="mb-4 p-4 bg-red-900/20 border border-red-500/30 rounded-xl">
          <p className="text-red-400 text-sm">❌ {error}</p>
        </div>
      )}
      
      <div className="flex items-center gap-3 mb-6">
        <Image size={24} className="text-purple-400" />
        <h3 className="font-playfair text-xl font-bold text-white">Configurar Imagem</h3>
      </div>

      {/* Current Hero Image Preview */}
      <div className="mb-6">
        <h3 className="font-inter font-medium text-white mb-3">Imagem Atual</h3>
        <div className="relative w-full h-40 rounded-xl overflow-hidden border border-gray-600/30">
          <img
            src={heroImageUrl}
            alt="Imagem atual do hero"
            className="w-full h-full object-cover"
            draggable="false"
            onContextMenu={(e) => e.preventDefault()}
            onDragStart={(e) => e.preventDefault()}
          />
          <div className="absolute inset-0 bg-black/40 flex items-center justify-center">
            <span className="text-white font-inter text-sm bg-black/60 backdrop-blur-sm px-4 py-2 rounded-full">
              Imagem de Fundo Atual
            </span>
          </div>
        </div>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* File Upload Area */}
        <div
          className={`relative border-2 border-dashed rounded-2xl p-8 text-center transition-all duration-300 ${
            dragActive
              ? 'border-purple-500 bg-purple-500/10 scale-[1.02]'
              : preview
              ? 'border-green-500 bg-green-500/10'
              : 'border-gray-600/50 hover:border-gray-500/70 hover:bg-gray-800/30'
          }`}
          onDragEnter={handleDrag}
          onDragLeave={handleDrag}
          onDragOver={handleDrag}
          onDrop={handleDrop}
        >
          <input
            ref={fileInputRef}
            type="file"
            accept="image/*"
            onChange={handleChange}
            className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
          />

          {preview ? (
            <div className="space-y-4">
              <div className="flex items-center justify-center gap-2 text-green-400 mb-4">
                <FileImage size={24} />
                <span className="font-inter font-medium">Nova imagem selecionada</span>
              </div>
              
              <img
                src={preview}
                alt="Preview"
                className="max-w-full max-h-48 mx-auto rounded-xl object-cover shadow-lg border border-gray-600/30"
              />
              
              <div className="bg-gray-800/50 rounded-lg p-3 text-left">
                <p className="text-white text-sm font-medium mb-1">{fileName}</p>
                <p className="text-gray-400 text-xs">Tamanho: {fileSize}</p>
              </div>
              
              <button
                type="button"
                onClick={resetForm}
                className="text-gray-400 hover:text-red-400 transition-colors duration-200 p-2 hover:bg-gray-800/50 rounded-lg"
              >
                <X size={18} />
              </button>
            </div>
          ) : (
            <div className="space-y-4">
              <div className="flex justify-center">
                <div className="w-16 h-16 bg-gray-700/50 rounded-2xl flex items-center justify-center">
                  <Image size={32} className="text-gray-400" />
                </div>
              </div>
              <div>
                <p className="font-inter text-white font-medium mb-2">
                  Arraste uma nova imagem aqui ou clique para selecionar
                </p>
                <p className="font-inter text-gray-400 text-sm">
                  Recomendado: 1920x1080px ou maior para melhor qualidade
                </p>
              </div>
            </div>
          )}
        </div>

        {/* Action Buttons */}
        <div className="flex gap-3">
          <button
            type="submit"
            disabled={uploading || !preview}
            className={`flex-1 py-4 px-6 rounded-xl font-inter font-semibold transition-all duration-300 flex items-center justify-center gap-3 ${
              success
                ? 'bg-green-600 text-white shadow-lg'
                : uploading || !preview
                ? 'bg-gray-700/50 text-gray-400 cursor-not-allowed'
                : 'bg-gradient-to-r from-purple-500 to-purple-600 hover:from-purple-600 hover:to-purple-700 text-white transform hover:scale-[1.02] shadow-lg'
            }`}
          >
            {success ? (
              <>
                <Check size={20} />
                Imagem atualizada!
              </>
            ) : uploading ? (
              <>
                <div className="animate-spin rounded-full h-6 w-6 border-2 border-white border-t-transparent"></div>
                Atualizando...
              </>
            ) : (
              <>
                <Upload size={22} />
                Atualizar Imagem
              </>
            )}
          </button>

          <div className="flex gap-2">
            <button
              type="button"
              onClick={handleReset}
              className="px-4 py-4 border-2 border-gray-600/50 text-gray-400 hover:border-gray-500/70 hover:text-white rounded-xl font-inter font-medium transition-all duration-300 flex items-center gap-2"
            >
              <RotateCcw size={18} />
              Padrão
            </button>
            
            <button
              type="button"
              onClick={handleRemove}
              className="px-4 py-4 border-2 border-red-600/50 text-red-400 hover:border-red-500/70 hover:text-red-300 hover:bg-red-900/20 rounded-xl font-inter font-medium transition-all duration-300 flex items-center gap-2"
            >
              <Trash2 size={18} />
              Remover
            </button>
          </div>
        </div>
      </form>
    </div>
  );
};

export default HeroImageForm;