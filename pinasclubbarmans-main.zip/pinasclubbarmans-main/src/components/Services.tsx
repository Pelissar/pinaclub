import React from 'react';
import { Wine, Palette, Droplets, Gift } from 'lucide-react';

const Services: React.FC = () => {
  const services = [
    {
      icon: Wine,
      title: 'Bar Premium Personalizado',
      description: 'Coquetéis clássicos e autorais criados especialmente para seu evento, com receitas exclusivas, ingredientes premium e apresentação impecável.',
      color: 'from-purple-500 to-purple-600'
    },
    {
      icon: Palette,
      title: 'Ambientação Temática',
      description: 'Criamos ambientações únicas que combinam perfeitamente com o tema do seu evento: tropical, vintage, rústico, moderno ou qualquer conceito personalizado.',
      color: 'from-blue-500 to-blue-600'
    },
    {
      icon: Droplets,
      title: 'Drinks Sem Álcool',
      description: 'Mocktails sofisticados e refrescantes para todos os gostos, incluindo opções especiais para crianças, gestantes e não bebedores.',
      color: 'from-cyan-500 to-cyan-600'
    },
    {
      icon: Gift,
      title: 'Open Bar Completo',
      description: 'Serviço premium com variedade ilimitada de bebidas nacionais e importadas, equipamentos profissionais e equipe dedicada durante todo o evento.',
      color: 'from-emerald-500 to-emerald-600'
    }
  ];

  return (
    <section id="services" className="py-20 bg-black relative overflow-hidden">
      {/* Animated Background */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-1/4 left-1/4 w-64 h-64 bg-gold-500 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-1/4 right-1/4 w-48 h-48 bg-gold-600 rounded-full blur-3xl animate-pulse animation-delay-1000"></div>
      </div>
      
      <div className="max-w-6xl mx-auto px-4">
        <div className="text-center mb-16 animate-fade-in-up">
          <h2 className="font-playfair text-4xl md:text-5xl font-bold text-white mb-6">
            Nossos Serviços
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-gold-500 to-gold-600 mx-auto rounded-full"></div>
          <p className="font-inter text-xl text-gray-400 max-w-2xl mx-auto mt-6">
            Oferecemos soluções completas em bartending para tornar seu evento único e memorável
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-8 animate-fade-in-up animation-delay-300">
          {services.map((service, index) => {
            const IconComponent = service.icon;
            return (
              <div 
                key={index}
                className={`group bg-gray-900/50 backdrop-blur border border-gray-800 rounded-2xl p-8 hover:border-gold-500/50 transition-all duration-500 hover:transform hover:scale-[1.02] hover:shadow-2xl hover:shadow-gold-500/10 cursor-pointer animate-fade-in-up`}
                style={{ animationDelay: `${index * 200}ms` }}
              >
                <div className="mb-6">
                  <div className={`w-16 h-16 bg-gradient-to-br ${service.color} rounded-xl flex items-center justify-center group-hover:scale-110 group-hover:rotate-6 transition-all duration-300 shadow-lg`}>
                    <IconComponent size={32} className="text-white" />
                  </div>
                </div>
                
                <h3 className="font-playfair text-2xl font-bold text-white mb-4 group-hover:text-gold-400 transition-colors duration-300 group-hover:translate-x-2">
                  {service.title}
                </h3>
                
                <p className="font-inter text-gray-300 leading-relaxed text-lg group-hover:text-gray-200 transition-colors duration-300">
                  {service.description}
                </p>
                
                {/* Hover indicator */}
                <div className="mt-6 opacity-0 group-hover:opacity-100 transition-opacity duration-300">
                  <div className="w-12 h-1 bg-gradient-to-r from-gold-500 to-gold-600 rounded-full"></div>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
};

export default Services;