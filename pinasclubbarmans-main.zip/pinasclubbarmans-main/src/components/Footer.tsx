import React from 'react';
import { Instagram, MessageCircle, Heart } from 'lucide-react';

const Footer: React.FC = () => {
  return (
    <footer className="bg-gray-900 border-t border-gray-800 relative overflow-hidden">
      {/* Background Pattern */}
      <div className="absolute inset-0 opacity-5">
        <div className="absolute top-8 left-1/4 w-32 h-32 bg-gold-500 rounded-full blur-3xl"></div>
        <div className="absolute bottom-8 right-1/4 w-24 h-24 bg-gold-600 rounded-full blur-3xl"></div>
      </div>
      
      <div className="max-w-6xl mx-auto px-4 py-12">
        <div className="text-center animate-fade-in-up">
          <h3 className="font-playfair text-3xl font-bold text-white mb-4">
            Piña Club Barmans
          </h3>
          
          <p className="font-inter text-gray-400 mb-8 max-w-md mx-auto">
            Coquetéis, estilo e momentos inesquecíveis para seu evento.
          </p>

          <div className="flex justify-center gap-6 mb-8">
            <a
              href="https://wa.me/5518996177463?text=Olá! Gostaria de solicitar um orçamento para meu evento."
              target="_blank"
              rel="noopener noreferrer"
              className="group w-12 h-12 bg-gradient-to-br from-gold-500 to-gold-600 rounded-full flex items-center justify-center hover:scale-110 transition-all duration-300 hover:shadow-2xl hover:shadow-gold-500/25"
            >
              <MessageCircle size={20} className="text-white group-hover:animate-pulse" />
            </a>
            
            <a
              href="https://instagram.com/pinaclubbarmans"
              target="_blank"
              rel="noopener noreferrer"
              className="group w-12 h-12 bg-gradient-to-br from-gold-500 to-gold-600 rounded-full flex items-center justify-center hover:scale-110 transition-all duration-300 hover:shadow-2xl hover:shadow-gold-500/25"
            >
              <Instagram size={20} className="text-white group-hover:animate-pulse" />
            </a>
          </div>

          <div className="border-t border-gray-800 pt-8">
            <p className="font-inter text-gray-500 flex items-center justify-center gap-2">
              © 2025 Piña Club Barmans 
              <span className="text-gold-500">|</span>
              Desenvolvido por{' '}
              <a
                href="https://instagram.com/lucas_pelissar"
                target="_blank"
                rel="noopener noreferrer"
                className="text-gold-400 hover:text-gold-300 transition-colors duration-200 font-medium"
              >
                Lucas Pelissar
              </a>
            </p>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;