import React from 'react';
import { MessageCircle } from 'lucide-react';
import { useHeroImage } from '../hooks/useHeroImage';

const Hero: React.FC = () => {
  const { heroImageUrl, isLoading } = useHeroImage();

  if (isLoading) {
    return (
      <section className="relative min-h-screen flex items-center justify-center overflow-hidden bg-gray-900">
        <div className="text-center">
          <div className="w-64 h-8 bg-gray-700 rounded mx-auto mb-4 animate-pulse"></div>
          <div className="w-48 h-6 bg-gray-700 rounded mx-auto animate-pulse"></div>
        </div>
      </section>
    );
  }

  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Background Image with Overlay */}
      <div className="absolute inset-0 z-0">
        <img 
          src={heroImageUrl}
          alt="Bartender profissional preparando drinks"
          className="w-full h-full object-cover select-none pointer-events-none no-select no-drag"
          loading="eager"
          decoding="async"
          draggable="false"
          onContextMenu={(e) => e.preventDefault()}
          onDragStart={(e) => e.preventDefault()}
        />
        <div className="absolute inset-0 bg-black/70"></div>
        
        {/* Marca d'água na imagem de fundo */}
        <div className="absolute bottom-4 right-4 flex items-center gap-2 bg-black/60 backdrop-blur-sm px-3 py-1 rounded-full opacity-70">
          <img 
            src="/Imagem do WhatsApp de 2025-07-21 à(s) 22.13.53_a3cebc65.jpg"
            alt="Piña Club Logo"
            className="w-6 h-6 rounded-full object-cover select-none pointer-events-none no-select no-drag"
            loading="lazy"
            decoding="async"
            draggable="false"
            onContextMenu={(e) => e.preventDefault()}
            onDragStart={(e) => e.preventDefault()}
          />
          <span className="font-playfair text-white font-bold text-sm">Piña Club</span>
        </div>
      </div>

      {/* Content */}
      <div className="relative z-10 text-center px-4 max-w-4xl mx-auto">
        <div className="animate-fade-in-up">
          <h1 className="font-playfair text-5xl md:text-7xl font-bold text-white mb-6 leading-tight animate-pulse-glow">
          Piña Club
          <span className="block text-gold-500">Barmans</span>
          </h1>
        </div>
        
        <div className="animate-fade-in-up animation-delay-300">
          <p className="font-inter text-xl md:text-2xl text-gray-200 mb-12 max-w-2xl mx-auto leading-relaxed">
          Transformamos seu evento em uma experiência única com drinks autorais e serviço premium
          </p>
        </div>

        <div className="animate-fade-in-up animation-delay-600 flex flex-col sm:flex-row gap-4 justify-center items-center">
          <a
            href="https://wa.me/5518996177463?text=Olá! Gostaria de solicitar um orçamento para meu evento. Podem me ajudar?"
            target="_blank"
            rel="noopener noreferrer"
            className="group bg-gradient-to-r from-gold-500 to-gold-600 hover:from-gold-600 hover:to-gold-700 text-white px-10 py-5 rounded-full font-inter font-semibold text-lg transition-all duration-300 hover:scale-105 hover:shadow-2xl hover:shadow-gold-500/25 flex items-center gap-3 min-w-[280px] justify-center shadow-lg animate-bounce-subtle"
          >
            <MessageCircle size={24} className="group-hover:animate-pulse" />
            Solicitar Orçamento
          </a>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div 
        className="absolute bottom-8 left-1/2 transform -translate-x-1/2 animate-bounce cursor-pointer hover:scale-110 transition-transform duration-300" 
        onClick={() => document.getElementById('about')?.scrollIntoView({ behavior: 'smooth' })}
        title="Rolar para baixo"
      >
        <div className="w-6 h-10 border-2 border-white rounded-full flex justify-center">
          <div className="w-1 h-3 bg-white rounded-full mt-2 animate-pulse"></div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
