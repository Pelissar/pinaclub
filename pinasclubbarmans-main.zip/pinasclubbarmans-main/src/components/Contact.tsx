import React from 'react';
import { Instagram, MessageCircle, Phone, MapPin, Martini } from 'lucide-react';

const Contact: React.FC = () => {
  return (
    <section id="contact" className="py-20 bg-black relative overflow-hidden">
      {/* Background Effects */}
      <div className="absolute inset-0 opacity-10">
        <div className="absolute top-20 left-1/3 w-48 h-48 bg-gold-500 rounded-full blur-3xl animate-pulse"></div>
        <div className="absolute bottom-20 right-1/3 w-40 h-40 bg-gold-600 rounded-full blur-3xl animate-pulse animation-delay-800"></div>
      </div>
      
      <div className="max-w-6xl mx-auto px-4">
        <div className="text-center mb-16 animate-fade-in-up">
          <h2 className="font-playfair text-4xl md:text-5xl font-bold text-white mb-6">
            Solicite Seu Orçamento
          </h2>
          <div className="w-24 h-1 bg-gradient-to-r from-gold-500 to-gold-600 mx-auto rounded-full mb-6"></div>
          <p className="font-inter text-xl text-gray-400 max-w-2xl mx-auto">
            Entre em contato conosco e receba um orçamento personalizado e sem compromisso para seu evento
          </p>
        </div>

        <div className="grid md:grid-cols-2 gap-12 items-center">
          <div className="space-y-8 animate-fade-in-left">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-gradient-to-br from-gold-500 to-gold-600 rounded-full flex items-center justify-center hover:scale-110 transition-transform duration-300 shadow-lg">
                <Phone size={24} className="text-white" />
              </div>
              <div>
                <h3 className="font-inter font-semibold text-white text-lg">Telefone/WhatsApp</h3>
                <p className="font-inter text-gray-400">(18) 99617-7463</p>
              </div>
            </div>

            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-gradient-to-br from-gold-500 to-gold-600 rounded-full flex items-center justify-center hover:scale-110 transition-transform duration-300 shadow-lg">
                <Instagram size={24} className="text-white" />
              </div>
              <div>
                <h3 className="font-inter font-semibold text-white text-lg">Instagram</h3>
                <p className="font-inter text-gray-400">@pinaclubbarmans</p>
              </div>
            </div>

            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-gradient-to-br from-gold-500 to-gold-600 rounded-full flex items-center justify-center hover:scale-110 transition-transform duration-300 shadow-lg">
                <MapPin size={24} className="text-white" />
              </div>
              <div>
                <h3 className="font-inter font-semibold text-white text-lg">Atendimento</h3>
                <p className="font-inter text-gray-400">Andradina-SP e região</p>
              </div>
            </div>
          </div>

          <div className="text-center animate-fade-in-right">
            <div className="bg-gray-900/50 backdrop-blur border border-gray-800 rounded-2xl p-8 hover:border-gold-500/30 transition-all duration-300 hover:shadow-2xl hover:shadow-gold-500/10">
              <h3 className="font-playfair text-2xl font-bold text-white mb-6">
                Fale Conosco Agora
              </h3>
              <p className="font-inter text-gray-400 mb-8">
                Resposta rápida e atendimento personalizado. Vamos criar juntos o bar perfeito para seu evento!
              </p>
              
              <div className="flex flex-col gap-4 justify-center">
                <a
                  href="https://wa.me/5518996177463?text=Olá! Gostaria de solicitar um orçamento para meu evento. Podem me ajudar?"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="group bg-gradient-to-r from-green-500 to-green-600 hover:from-green-600 hover:to-green-700 text-white px-10 py-5 rounded-full font-inter font-semibold text-lg transition-all duration-300 transform hover:scale-105 hover:shadow-2xl hover:shadow-green-500/25 flex items-center gap-3 justify-center shadow-lg"
                >
                  <MessageCircle size={24} className="group-hover:animate-pulse" />
                  Conversar no WhatsApp
                </a>
                
                <a
                  href="https://instagram.com/pinaclubbarmans"
                  target="_blank"
                  rel="noopener noreferrer"
                  className="group border-2 border-gold-500 text-gold-500 hover:bg-gold-500 hover:text-white px-10 py-4 rounded-full font-inter font-medium text-lg transition-all duration-300 transform hover:scale-105 hover:shadow-2xl hover:shadow-gold-500/25 flex items-center gap-3 justify-center"
                >
                  <Instagram size={24} className="group-hover:animate-pulse" />
                  Seguir no Instagram
                </a>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Contact;