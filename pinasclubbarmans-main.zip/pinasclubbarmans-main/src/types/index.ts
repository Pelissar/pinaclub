export interface GalleryItem {
  id: string;
  url: string;
  caption: string;
  type: 'image' | 'video';
  createdAt: string;
}

export interface UploadData {
  file: File;
  caption: string;
}

export interface Testimonial {
  id: string;
  clientName: string;
  clientPhoto: string;
  testimonialText: string;
  rating: number;
  eventType: string;
  createdAt: string;
}