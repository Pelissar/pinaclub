import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { isSupabaseConfigured } from '../lib/supabase';

export interface GalleryItem {
  id: string;
  url: string;
  caption: string;
  type: 'image' | 'video';
  createdAt: string;
}

export const useGallery = () => {
  const [items, setItems] = useState<GalleryItem[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    loadGallery();
    
    // Subscribe to real-time changes
    const subscription = supabase
      .channel('gallery_changes')
      .on('postgres_changes', 
        { event: '*', schema: 'public', table: 'gallery_items' },
        (payload) => {
          console.log('🔄 Gallery real-time update:', payload);
          loadGallery(); // Reload data when changes occur
        }
      )
      .subscribe();

    return () => {
      subscription.unsubscribe();
    };
  }, []);

  const loadGallery = async () => {
    try {
      setError(null);
      
      if (!isSupabaseConfigured()) {
        console.log('📱 Supabase não configurado, usando galeria vazia');
        setItems([]);
        return;
      }
      
      console.log('📸 Loading gallery from Supabase...');
      const { data, error } = await supabase
        .from('gallery_items')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) {
        console.log('📱 No gallery items found, using empty gallery');
        setItems([]);
        return;
      }

      // Transform data to match our interface
      const transformedItems: GalleryItem[] = (data || []).map(item => ({
        id: item.id,
        url: item.url,
        caption: item.caption,
        type: item.type,
        createdAt: item.created_at
      }));

      console.log('✅ Gallery loaded from Supabase:', transformedItems.length, 'items');
      setItems(transformedItems);
    } catch (error) {
      console.error('❌ Error in loadGallery:', error);
      setError(error instanceof Error ? error.message : 'Unknown error');
    } finally {
      setIsLoading(false);
    }
  };

  const addItem = async (url: string, caption: string, type: 'image' | 'video' = 'image') => {
    try {
      setError(null);
      
      if (!isSupabaseConfigured()) {
        throw new Error('Supabase não configurado. Configure as variáveis de ambiente.');
      }
      
      console.log('➕ Adding item to Supabase:', { caption, type });

      const { data, error } = await supabase
        .from('gallery_items')
        .insert([
          {
            url,
            caption,
            type,
            created_at: new Date().toISOString()
          }
        ])
        .select()
        .single();

      if (error) {
        console.error('❌ Error adding item:', error);
        setError(error.message);
        throw error;
      }

      console.log('✅ Item added to Supabase:', data);
      
      // Transform and return the new item
      const newItem: GalleryItem = {
        id: data.id,
        url: data.url,
        caption: data.caption,
        type: data.type,
        createdAt: data.created_at
      };

      // Update local state immediately
      setItems(prev => [newItem, ...prev]);
      
      return newItem;
    } catch (error) {
      console.error('❌ Error in addItem:', error);
      setError(error instanceof Error ? error.message : 'Unknown error');
      throw error;
    }
  };

  const removeItem = async (id: string) => {
    try {
      setError(null);
      
      if (!isSupabaseConfigured()) {
        throw new Error('Supabase não configurado. Configure as variáveis de ambiente.');
      }
      
      console.log('🗑️ Removing item from Supabase:', id);

      const { error } = await supabase
        .from('gallery_items')
        .delete()
        .eq('id', id);

      if (error) {
        console.error('❌ Error removing item:', error);
        setError(error.message);
        throw error;
      }

      console.log('✅ Item removed from Supabase');
      
      // Update local state immediately
      setItems(prev => prev.filter(item => item.id !== id));
    } catch (error) {
      console.error('❌ Error in removeItem:', error);
      setError(error instanceof Error ? error.message : 'Unknown error');
      throw error;
    }
  };

  return {
    items,
    isLoading,
    error,
    addItem,
    removeItem,
    refreshGallery: loadGallery
  };
};