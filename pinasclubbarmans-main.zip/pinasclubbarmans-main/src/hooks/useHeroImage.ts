import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { isSupabaseConfigured } from '../lib/supabase';

const DEFAULT_HERO_IMAGE = 'https://images.pexels.com/photos/338713/pexels-photo-338713.jpeg?auto=compress&cs=tinysrgb&w=1920';

export const useHeroImage = () => {
  const [heroImageUrl, setHeroImageUrl] = useState<string>(DEFAULT_HERO_IMAGE);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    loadHeroImage();
    
    // Subscribe to real-time changes
    const subscription = supabase
      .channel('site_settings_changes')
      .on('postgres_changes', 
        { 
          event: '*', 
          schema: 'public', 
          table: 'site_settings',
          filter: 'setting_key=eq.hero_image'
        },
        (payload) => {
          console.log('🔄 Hero image real-time update:', payload);
          loadHeroImage();
        }
      )
      .subscribe();

    return () => {
      subscription.unsubscribe();
    };
  }, []);

  const loadHeroImage = async () => {
    try {
      setError(null);
      
      if (!isSupabaseConfigured()) {
        console.log('📱 Supabase não configurado, usando imagem padrão');
        setHeroImageUrl(DEFAULT_HERO_IMAGE);
        return;
      }
      
      console.log('🖼️ Loading hero image from Supabase...');
      const { data, error } = await supabase
        .from('site_settings')
        .select('setting_value')
        .eq('setting_key', 'hero_image')
        .single();

      if (error) {
        console.log('📱 No hero image found in database, using default');
        setHeroImageUrl(DEFAULT_HERO_IMAGE);
        return;
      }

      if (data?.setting_value) {
        console.log('✅ Hero image loaded from Supabase:', data.setting_value.substring(0, 50) + '...');
        setHeroImageUrl(data.setting_value);
      } else {
        console.log('🖼️ No hero image found, using default');
        setHeroImageUrl(DEFAULT_HERO_IMAGE);
      }
    } catch (error) {
      console.error('❌ Error in loadHeroImage:', error);
      setError(error instanceof Error ? error.message : 'Unknown error');
      setHeroImageUrl(DEFAULT_HERO_IMAGE);
    } finally {
      setIsLoading(false);
    }
  };

  const updateHeroImage = async (url: string) => {
    try {
      setError(null);
      
      if (!isSupabaseConfigured()) {
        throw new Error('Supabase não configurado. Configure as variáveis de ambiente.');
      }
      
      console.log('🖼️ Updating hero image in Supabase:', url.substring(0, 50) + '...');

      const { error } = await supabase
        .from('site_settings')
        .upsert({
          setting_key: 'hero_image',
          setting_value: url,
          setting_type: 'image',
          updated_at: new Date().toISOString()
        });

      if (error) {
        console.error('❌ Error updating hero image:', error);
        setError(error.message);
        throw error;
      }

      console.log('✅ Hero image updated in Supabase');
      setHeroImageUrl(url);
    } catch (error) {
      console.error('❌ Error in updateHeroImage:', error);
      setError(error instanceof Error ? error.message : 'Unknown error');
      throw error;
    }
  };

  const resetToDefault = async () => {
    try {
      setError(null);
      
      if (!isSupabaseConfigured()) {
        throw new Error('Supabase não configurado. Configure as variáveis de ambiente.');
      }
      
      console.log('🔄 Resetting hero image to default');

      const { error } = await supabase
        .from('site_settings')
        .upsert({
          setting_key: 'hero_image',
          setting_value: DEFAULT_HERO_IMAGE,
          setting_type: 'image',
          updated_at: new Date().toISOString()
        });

      if (error) {
        console.error('❌ Error resetting hero image:', error);
        setError(error.message);
        throw error;
      }

      console.log('✅ Hero image reset to default');
      setHeroImageUrl(DEFAULT_HERO_IMAGE);
    } catch (error) {
      console.error('❌ Error in resetToDefault:', error);
      setError(error instanceof Error ? error.message : 'Unknown error');
      throw error;
    }
  };

  const removeHeroImage = async () => {
    try {
      setError(null);
      
      if (!isSupabaseConfigured()) {
        throw new Error('Supabase não configurado. Configure as variáveis de ambiente.');
      }
      
      console.log('🗑️ Removing hero image from Supabase');

      const { error } = await supabase
        .from('site_settings')
        .delete()
        .eq('setting_key', 'hero_image');

      if (error) {
        console.error('❌ Error removing hero image:', error);
        setError(error.message);
        throw error;
      }

      console.log('✅ Hero image removed from Supabase');
      setHeroImageUrl(DEFAULT_HERO_IMAGE);
    } catch (error) {
      console.error('❌ Error in removeHeroImage:', error);
      setError(error instanceof Error ? error.message : 'Unknown error');
      throw error;
    }
  };

  return {
    heroImageUrl,
    isLoading,
    error,
    updateHeroImage,
    resetToDefault,
    removeHeroImage,
    refreshHeroImage: loadHeroImage
  };
};