import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { isSupabaseConfigured } from '../lib/supabase';

export interface Testimonial {
  id: string;
  clientName: string;
  clientPhoto: string;
  testimonialText: string;
  rating: number;
  eventType: string;
  createdAt: string;
}

export const useTestimonials = () => {
  const [testimonials, setTestimonials] = useState<Testimonial[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    loadTestimonials();
    
    // Subscribe to real-time changes
    const subscription = supabase
      .channel('testimonials_changes')
      .on('postgres_changes', 
        { event: '*', schema: 'public', table: 'testimonials' },
        (payload) => {
          console.log('🔄 Testimonials real-time update:', payload);
          loadTestimonials(); // Reload data when changes occur
        }
      )
      .subscribe();

    return () => {
      subscription.unsubscribe();
    };
  }, []);

  const loadTestimonials = async () => {
    try {
      setError(null);
      
      if (!isSupabaseConfigured()) {
        console.log('📱 Supabase não configurado, usando depoimentos vazios');
        setTestimonials([]);
        return;
      }
      
      console.log('💬 Loading testimonials from Supabase...');
      const { data, error } = await supabase
        .from('testimonials')
        .select('*')
        .order('created_at', { ascending: false });

      if (error) {
        console.log('📱 No testimonials found, using empty list');
        setTestimonials([]);
        return;
      }

      // Transform data to match our interface
      const transformedTestimonials: Testimonial[] = (data || []).map(item => ({
        id: item.id,
        clientName: item.client_name,
        clientPhoto: item.client_photo,
        testimonialText: item.testimonial_text || '',
        rating: item.rating,
        eventType: item.event_type,
        createdAt: item.created_at
      }));

      console.log('✅ Testimonials loaded from Supabase:', transformedTestimonials.length, 'items');
      setTestimonials(transformedTestimonials);
    } catch (error) {
      console.error('❌ Error in loadTestimonials:', error);
      setError(error instanceof Error ? error.message : 'Unknown error');
    } finally {
      setIsLoading(false);
    }
  };

  const addTestimonial = async (
    clientName: string,
    clientPhoto: string,
    testimonialText: string,
    rating: number,
    eventType: string
  ) => {
    try {
      setError(null);
      
      if (!isSupabaseConfigured()) {
        throw new Error('Supabase não configurado. Configure as variáveis de ambiente.');
      }
      
      console.log('➕ Adding testimonial to Supabase:', { clientName, eventType, rating });

      const { data, error } = await supabase
        .from('testimonials')
        .insert([
          {
            client_name: clientName,
            client_photo: clientPhoto,
            testimonial_text: testimonialText,
            rating,
            event_type: eventType,
            created_at: new Date().toISOString()
          }
        ])
        .select()
        .single();

      if (error) {
        console.error('❌ Error adding testimonial:', error);
        setError(error.message);
        throw error;
      }

      console.log('✅ Testimonial added to Supabase:', data);
      
      // Transform and return the new testimonial
      const newTestimonial: Testimonial = {
        id: data.id,
        clientName: data.client_name,
        clientPhoto: data.client_photo,
        testimonialText: data.testimonial_text || '',
        rating: data.rating,
        eventType: data.event_type,
        createdAt: data.created_at
      };

      // Update local state immediately
      setTestimonials(prev => [newTestimonial, ...prev]);
      
      return newTestimonial;
    } catch (error) {
      console.error('❌ Error in addTestimonial:', error);
      setError(error instanceof Error ? error.message : 'Unknown error');
      throw error;
    }
  };

  const removeTestimonial = async (id: string) => {
    try {
      setError(null);
      
      if (!isSupabaseConfigured()) {
        throw new Error('Supabase não configurado. Configure as variáveis de ambiente.');
      }
      
      console.log('🗑️ Removing testimonial from Supabase:', id);

      const { error } = await supabase
        .from('testimonials')
        .delete()
        .eq('id', id);

      if (error) {
        console.error('❌ Error removing testimonial:', error);
        setError(error.message);
        throw error;
      }

      console.log('✅ Testimonial removed from Supabase');
      
      // Update local state immediately
      setTestimonials(prev => prev.filter(testimonial => testimonial.id !== id));
    } catch (error) {
      console.error('❌ Error in removeTestimonial:', error);
      setError(error instanceof Error ? error.message : 'Unknown error');
      throw error;
    }
  };

  return {
    testimonials,
    isLoading,
    error,
    addTestimonial,
    removeTestimonial,
    refreshTestimonials: loadTestimonials
  };
};