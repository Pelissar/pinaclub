import { useState, useEffect } from 'react';
import { supabase } from '../lib/supabase';
import { isSupabaseConfigured } from '../lib/supabase';

const DEFAULT_VIDEO_URL = 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4';

export const useAboutVideo = () => {
  const [videoUrl, setVideoUrl] = useState<string>('');
  const [isLoading, setIsLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    loadVideo();
    
    // Subscribe to real-time changes
    const subscription = supabase
      .channel('about_video_changes')
      .on('postgres_changes', 
        { 
          event: '*', 
          schema: 'public', 
          table: 'site_settings',
          filter: 'setting_key=eq.about_video'
        },
        (payload) => {
          console.log('🔄 About video real-time update:', payload);
          loadVideo();
        }
      )
      .subscribe();

    return () => {
      subscription.unsubscribe();
    };
  }, []);

  const loadVideo = async () => {
    try {
      setError(null);
      
      if (!isSupabaseConfigured()) {
        console.log('📱 Supabase não configurado, usando vídeo vazio');
        setVideoUrl('');
        return;
      }
      
      console.log('🎬 Loading about video from Supabase...');
      const { data, error } = await supabase
        .from('site_settings')
        .select('setting_value')
        .eq('setting_key', 'about_video')
        .single();

      if (error) {
        console.log('📱 No video found in database, using empty');
        setVideoUrl('');
        return;
      }

      if (data?.setting_value) {
        console.log('✅ About video loaded from Supabase:', data.setting_value.substring(0, 50) + '...');
        setVideoUrl(data.setting_value);
      } else {
        console.log('🎬 No about video found, using empty');
        setVideoUrl('');
      }
    } catch (error) {
      console.error('❌ Error in loadVideo:', error);
      setError(error instanceof Error ? error.message : 'Unknown error');
      setVideoUrl('');
    } finally {
      setIsLoading(false);
    }
  };

  const updateVideo = async (url: string) => {
    try {
      setError(null);
      
      if (!isSupabaseConfigured()) {
        throw new Error('Supabase não configurado. Configure as variáveis de ambiente.');
      }
      
      console.log('🎬 Updating about video in Supabase:', url.substring(0, 50) + '...');

      const { error } = await supabase
        .from('site_settings')
        .upsert({
          setting_key: 'about_video',
          setting_value: url,
          setting_type: 'video',
          updated_at: new Date().toISOString()
        });

      if (error) {
        console.error('❌ Error updating about video:', error);
        setError(error.message);
        throw error;
      }

      console.log('✅ About video updated in Supabase');
      setVideoUrl(url);
    } catch (error) {
      console.error('❌ Error in updateVideo:', error);
      setError(error instanceof Error ? error.message : 'Unknown error');
      throw error;
    }
  };

  const resetToDefault = async () => {
    try {
      setError(null);
      
      if (!isSupabaseConfigured()) {
        throw new Error('Supabase não configurado. Configure as variáveis de ambiente.');
      }
      
      console.log('🔄 Resetting about video to default');

      const { error } = await supabase
        .from('site_settings')
        .upsert({
          setting_key: 'about_video',
          setting_value: DEFAULT_VIDEO_URL,
          setting_type: 'video',
          updated_at: new Date().toISOString()
        });

      if (error) {
        console.error('❌ Error resetting about video:', error);
        setError(error.message);
        throw error;
      }

      console.log('✅ About video reset to default');
      setVideoUrl(DEFAULT_VIDEO_URL);
    } catch (error) {
      console.error('❌ Error in resetToDefault:', error);
      setError(error instanceof Error ? error.message : 'Unknown error');
      throw error;
    }
  };

  const removeVideo = async () => {
    try {
      setError(null);
      
      if (!isSupabaseConfigured()) {
        throw new Error('Supabase não configurado. Configure as variáveis de ambiente.');
      }
      
      console.log('🗑️ Removing about video from Supabase');

      const { error } = await supabase
        .from('site_settings')
        .delete()
        .eq('setting_key', 'about_video');

      if (error) {
        console.error('❌ Error removing about video:', error);
        setError(error.message);
        throw error;
      }

      console.log('✅ About video removed from Supabase');
      setVideoUrl(DEFAULT_VIDEO_URL);
    } catch (error) {
      console.error('❌ Error in removeVideo:', error);
      setError(error instanceof Error ? error.message : 'Unknown error');
      throw error;
    }
  };

  return {
    videoUrl,
    isLoading,
    error,
    updateVideo,
    resetToDefault,
    removeVideo,
    refreshVideo: loadVideo
  };
};