import { useState, useEffect } from 'react';

interface AnalyticsData {
  totalVisits: number;
  uniqueVisitors: number;
  visitHistory: VisitRecord[];
  lastUpdated: string;
  sessionId: string;
}

interface VisitRecord {
  ip: string;
  timestamp: string;
  userAgent: string;
  page: string;
  sessionId: string;
}

const STORAGE_KEY = 'pinaclub_analytics';
const STORAGE_VERSION_KEY = 'pinaclub_analytics_version';
const SESSION_KEY = 'pinaclub_session';

// Função para obter IP aproximado (usando serviços públicos)
const getVisitorIP = async (): Promise<string> => {
  try {
    // Tentar múltiplos serviços para obter IP
    const services = [
      'https://api.ipify.org?format=json',
      'https://ipapi.co/json/',
      'https://httpbin.org/ip'
    ];

    for (const service of services) {
      try {
        const response = await fetch(service);
        const data = await response.json();
        return data.ip || data.origin || 'unknown';
      } catch (error) {
        console.warn(`Failed to get IP from ${service}:`, error);
        continue;
      }
    }
    
    // Fallback: gerar um ID único baseado no browser
    return generateBrowserFingerprint();
  } catch (error) {
    console.error('Error getting visitor IP:', error);
    return generateBrowserFingerprint();
  }
};

// Gerar fingerprint único do browser como fallback
const generateBrowserFingerprint = (): string => {
  const canvas = document.createElement('canvas');
  const ctx = canvas.getContext('2d');
  if (ctx) {
    ctx.textBaseline = 'top';
    ctx.font = '14px Arial';
    ctx.fillText('Browser fingerprint', 2, 2);
  }
  
  const fingerprint = [
    navigator.userAgent,
    navigator.language,
    screen.width + 'x' + screen.height,
    new Date().getTimezoneOffset(),
    canvas.toDataURL()
  ].join('|');
  
  // Criar hash simples
  let hash = 0;
  for (let i = 0; i < fingerprint.length; i++) {
    const char = fingerprint.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash; // Convert to 32-bit integer
  }
  
  return `fp_${Math.abs(hash).toString(36)}`;
};

// Gerar ID único da sessão
const generateSessionId = (): string => {
  return `session_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`;
};

// Verificar se é uma nova sessão (30 minutos de timeout)
const isNewSession = (): boolean => {
  const sessionData = sessionStorage.getItem(SESSION_KEY);
  if (!sessionData) return true;
  
  try {
    const { timestamp } = JSON.parse(sessionData);
    const now = Date.now();
    const sessionTimeout = 30 * 60 * 1000; // 30 minutos
    
    return (now - timestamp) > sessionTimeout;
  } catch {
    return true;
  }
};

// Salvar sessão atual
const saveSession = (sessionId: string) => {
  const sessionData = {
    sessionId,
    timestamp: Date.now()
  };
  sessionStorage.setItem(SESSION_KEY, JSON.stringify(sessionData));
};

// Obter ID da sessão atual
const getCurrentSessionId = (): string => {
  const sessionData = sessionStorage.getItem(SESSION_KEY);
  if (sessionData) {
    try {
      const { sessionId } = JSON.parse(sessionData);
      return sessionId;
    } catch {
      // Se erro, criar nova sessão
    }
  }
  
  const newSessionId = generateSessionId();
  saveSession(newSessionId);
  return newSessionId;
};

export const useAnalytics = () => {
  const [analytics, setAnalytics] = useState<AnalyticsData>({
    totalVisits: 0,
    uniqueVisitors: 0,
    visitHistory: [],
    lastUpdated: new Date().toISOString(),
    sessionId: ''
  });
  const [isLoading, setIsLoading] = useState(true);
  const [hasTrackedThisSession, setHasTrackedThisSession] = useState(false);

  useEffect(() => {
    loadAnalytics();
    
    // Só rastrear visita se for uma nova sessão
    if (isNewSession() && !hasTrackedThisSession) {
      trackVisit();
      setHasTrackedThisSession(true);
    }
  }, []);

  const loadAnalytics = () => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        const parsedData = JSON.parse(stored);
        setAnalytics(parsedData);
      }
    } catch (error) {
      console.error('Error loading analytics:', error);
    } finally {
      setIsLoading(false);
    }
  };

  const saveAnalytics = (data: AnalyticsData) => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(data));
      const version = Date.now().toString();
      localStorage.setItem(STORAGE_VERSION_KEY, version);
      
      // Atualizar estado local imediatamente
      setAnalytics(data);
      
      // Disparar evento para sincronizar outras instâncias
      window.dispatchEvent(new CustomEvent('analyticsUpdated', { 
        detail: { data, version } 
      }));
    } catch (error) {
      console.error('Error saving analytics:', error);
    }
  };

  const trackVisit = async () => {
    try {
      // Verificar se já rastreou nesta sessão
      if (hasTrackedThisSession) {
        console.log('📊 Visit already tracked in this session');
        return;
      }
      
      const ip = await getVisitorIP();
      const currentPage = window.location.pathname;
      const userAgent = navigator.userAgent;
      const timestamp = new Date().toISOString();
      const sessionId = getCurrentSessionId();

      // Carregar dados atuais
      const stored = localStorage.getItem(STORAGE_KEY);
      let currentData: AnalyticsData = stored ? JSON.parse(stored) : {
        totalVisits: 0,
        uniqueVisitors: 0,
        visitHistory: [],
        lastUpdated: timestamp,
        sessionId: getCurrentSessionId()
      };

      // Verificar se é um visitante único (mesmo IP nas últimas 24h)
      const oneDayAgo = new Date(Date.now() - 24 * 60 * 60 * 1000);
      const recentVisitFromSameIP = currentData.visitHistory.find(visit => 
        visit.ip === ip && 
        new Date(visit.timestamp) > oneDayAgo &&
        visit.sessionId !== sessionId // Diferente sessão
      );

      const newVisit: VisitRecord = {
        ip,
        timestamp,
        userAgent,
        page: currentPage,
        sessionId
      };

      // Atualizar dados
      const updatedData: AnalyticsData = {
        totalVisits: currentData.totalVisits + 1,
        uniqueVisitors: recentVisitFromSameIP ? currentData.uniqueVisitors : currentData.uniqueVisitors + 1,
        visitHistory: [newVisit, ...currentData.visitHistory].slice(0, 1000), // Manter apenas os últimos 1000 registros
        lastUpdated: timestamp,
        sessionId: sessionId
      };

      saveAnalytics(updatedData);
      setHasTrackedThisSession(true);
      
      // Salvar sessão para evitar múltiplos rastreamentos
      saveSession(sessionId);

      console.log('📊 Visit tracked:', {
        ip: ip.substring(0, 8) + '...',
        sessionId: sessionId.substring(0, 15) + '...',
        isUnique: !recentVisitFromSameIP,
        totalVisits: updatedData.totalVisits,
        uniqueVisitors: updatedData.uniqueVisitors
      });

    } catch (error) {
      console.error('Error tracking visit:', error);
    }
  };

  const getVisitsByPeriod = (days: number) => {
    const cutoffDate = new Date(Date.now() - days * 24 * 60 * 60 * 1000);
    return analytics.visitHistory.filter(visit => 
      new Date(visit.timestamp) > cutoffDate
    );
  };

  const getUniqueVisitorsByPeriod = (days: number) => {
    const visits = getVisitsByPeriod(days);
    const uniqueIPs = new Set(visits.map(visit => visit.ip));
    return uniqueIPs.size;
  };

  const clearAnalytics = () => {
    const clearedData: AnalyticsData = {
      totalVisits: 0,
      uniqueVisitors: 0,
      visitHistory: [],
      lastUpdated: new Date().toISOString(),
      sessionId: getCurrentSessionId()
    };
    
    setAnalytics(clearedData);
    saveAnalytics(clearedData);
    
    // Limpar também a sessão
    sessionStorage.removeItem(SESSION_KEY);
    setHasTrackedThisSession(false);
    
    console.log('🧹 Analytics cleared - Dashboard should update immediately');
  };

  // Escutar eventos de atualização do analytics
  useEffect(() => {
    const handleAnalyticsUpdate = (event: Event) => {
      const customEvent = event as CustomEvent;
      const { data } = customEvent.detail;
      console.log('📊 Analytics updated via event:', data.totalVisits, 'visits');
      setAnalytics(data);
    };

    const handleStorageChange = (event: StorageEvent) => {
      if (event.key === STORAGE_KEY && event.newValue) {
        try {
          const newData = JSON.parse(event.newValue);
          console.log('📊 Analytics updated via storage event:', newData.totalVisits, 'visits');
          setAnalytics(newData);
        } catch (error) {
          console.error('Error parsing analytics storage event:', error);
        }
      }
    };

    window.addEventListener('analyticsUpdated', handleAnalyticsUpdate);
    window.addEventListener('storage', handleStorageChange);
    
    return () => {
      window.removeEventListener('analyticsUpdated', handleAnalyticsUpdate);
      window.removeEventListener('storage', handleStorageChange);
    };
  }, []);

  return {
    analytics,
    isLoading,
    getVisitsByPeriod,
    getUniqueVisitorsByPeriod,
    clearAnalytics,
    refreshAnalytics: loadAnalytics
  };
};