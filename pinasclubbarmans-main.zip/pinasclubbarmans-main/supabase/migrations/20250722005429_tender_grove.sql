/*
  # Criar tabelas para galeria e depoimentos

  1. Novas Tabelas
    - `gallery_items`
      - `id` (uuid, primary key)
      - `url` (text, URL da imagem/vídeo)
      - `caption` (text, legenda)
      - `type` (text, tipo: image ou video)
      - `created_at` (timestamp)
    - `testimonials`
      - `id` (uuid, primary key)
      - `client_name` (text, nome do cliente)
      - `client_photo` (text, URL da foto do cliente)
      - `testimonial_text` (text, texto do depoimento)
      - `rating` (integer, avaliação de 1-5)
      - `event_type` (text, tipo de evento)
      - `created_at` (timestamp)

  2. Segurança
    - Habilitar RLS em ambas as tabelas
    - Permitir leitura pública para exibir na landing page
    - Permitir inserção/atualização/exclusão apenas para usuários autenticados
*/

-- Criar tabela de itens da galeria
CREATE TABLE IF NOT EXISTS gallery_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  url text NOT NULL,
  caption text NOT NULL,
  type text NOT NULL DEFAULT 'image' CHECK (type IN ('image', 'video')),
  created_at timestamptz DEFAULT now()
);

-- Criar tabela de depoimentos
CREATE TABLE IF NOT EXISTS testimonials (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  client_name text NOT NULL,
  client_photo text NOT NULL,
  testimonial_text text NOT NULL,
  rating integer NOT NULL DEFAULT 5 CHECK (rating >= 1 AND rating <= 5),
  event_type text NOT NULL,
  created_at timestamptz DEFAULT now()
);

-- Habilitar RLS
ALTER TABLE gallery_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE testimonials ENABLE ROW LEVEL SECURITY;

-- Políticas para gallery_items
CREATE POLICY "Permitir leitura pública da galeria"
  ON gallery_items
  FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Permitir inserção para usuários autenticados"
  ON gallery_items
  FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Permitir atualização para usuários autenticados"
  ON gallery_items
  FOR UPDATE
  TO authenticated
  USING (true);

CREATE POLICY "Permitir exclusão para usuários autenticados"
  ON gallery_items
  FOR DELETE
  TO authenticated
  USING (true);

-- Políticas para testimonials
CREATE POLICY "Permitir leitura pública dos depoimentos"
  ON testimonials
  FOR SELECT
  TO anon, authenticated
  USING (true);

CREATE POLICY "Permitir inserção para usuários autenticados"
  ON testimonials
  FOR INSERT
  TO authenticated
  WITH CHECK (true);

CREATE POLICY "Permitir atualização para usuários autenticados"
  ON testimonials
  FOR UPDATE
  TO authenticated
  USING (true);

CREATE POLICY "Permitir exclusão para usuários autenticados"
  ON testimonials
  FOR DELETE
  TO authenticated
  USING (true);

-- Inserir dados iniciais da galeria
INSERT INTO gallery_items (url, caption, type) VALUES
  ('https://images.pexels.com/photos/338713/pexels-photo-338713.jpeg?auto=compress&cs=tinysrgb&w=800', 'Drinks autorais em evento corporativo', 'image'),
  ('https://images.pexels.com/photos/1283219/pexels-photo-1283219.jpeg?auto=compress&cs=tinysrgb&w=800', 'Bartender performático em ação', 'image'),
  ('https://images.pexels.com/photos/1267320/pexels-photo-1267320.jpeg?auto=compress&cs=tinysrgb&w=800', 'Bar temático tropical para casamento', 'image'),
  ('https://images.pexels.com/photos/2647943/pexels-photo-2647943.jpeg?auto=compress&cs=tinysrgb&w=800', 'Coquetéis coloridos e criativos', 'image'),
  ('https://images.pexels.com/photos/1089932/pexels-photo-1089932.jpeg?auto=compress&cs=tinysrgb&w=800', 'Setup completo para festa privada', 'image'),
  ('https://images.pexels.com/photos/1850595/pexels-photo-1850595.jpeg?auto=compress&cs=tinysrgb&w=800', 'Mocktails premium sem álcool', 'image');

-- Inserir dados iniciais de depoimentos
INSERT INTO testimonials (client_name, client_photo, testimonial_text, rating, event_type) VALUES
  ('Maria Silva', 'https://images.pexels.com/photos/774909/pexels-photo-774909.jpeg?auto=compress&cs=tinysrgb&w=150', 'O serviço da Piña Club foi excepcional! Os drinks estavam perfeitos e os bartenders foram super profissionais. Nosso casamento ficou inesquecível!', 5, 'Casamento'),
  ('João Santos', 'https://images.pexels.com/photos/1222271/pexels-photo-1222271.jpeg?auto=compress&cs=tinysrgb&w=150', 'Contratamos para nossa festa de aniversário e foi um sucesso total! Os convidados não paravam de elogiar os coquetéis autorais.', 5, 'Aniversário'),
  ('Ana Costa', 'https://images.pexels.com/photos/1239291/pexels-photo-1239291.jpeg?auto=compress&cs=tinysrgb&w=150', 'Profissionais incríveis! O bar temático tropical ficou lindo e os drinks sem álcool foram um diferencial para nosso evento corporativo.', 5, 'Evento Corporativo');