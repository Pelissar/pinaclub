/*
  # Adicionar tabela de configurações do site

  1. Nova Tabela
    - `site_settings`
      - `id` (uuid, primary key)
      - `setting_key` (text, unique) - Chave da configuração (ex: 'hero_image', 'about_video')
      - `setting_value` (text) - Valor da configuração (URL da imagem/vídeo)
      - `setting_type` (text) - Tipo da configuração ('image', 'video', 'text')
      - `created_at` (timestamp)
      - `updated_at` (timestamp)

  2. Segurança
    - Enable RLS na tabela `site_settings`
    - Política para leitura pública
    - Política para escrita apenas por usuários autenticados

  3. Dados Iniciais
    - Configuração padrão para hero_image
    - Configuração padrão para about_video
*/

CREATE TABLE IF NOT EXISTS site_settings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  setting_key text UNIQUE NOT NULL,
  setting_value text NOT NULL,
  setting_type text NOT NULL DEFAULT 'text',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE site_settings ENABLE ROW LEVEL SECURITY;

-- Política para leitura pública
CREATE POLICY "Permitir leitura pública das configurações"
  ON site_settings
  FOR SELECT
  TO anon, authenticated
  USING (true);

-- Política para escrita apenas por usuários autenticados
CREATE POLICY "Permitir atualização para usuários autenticados"
  ON site_settings
  FOR ALL
  TO authenticated
  USING (true)
  WITH CHECK (true);

-- Inserir configurações padrão
INSERT INTO site_settings (setting_key, setting_value, setting_type) VALUES
  ('hero_image', 'https://images.pexels.com/photos/338713/pexels-photo-338713.jpeg?auto=compress&cs=tinysrgb&w=1920', 'image'),
  ('about_video', 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/BigBuckBunny.mp4', 'video')
ON CONFLICT (setting_key) DO NOTHING;